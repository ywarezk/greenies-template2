<?php
/**
 * Jay functions and definitions
 *
 * @package Jay
 */

define( 'JAY_VERSION', '1.7' );

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

if ( ! function_exists( 'mondo_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function mondo_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Jay, use a find and replace
	 * to change 'mondo' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'mondo', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'mondo' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'image', 'audio', 'video', 'gallery', 'quote', 'link'
	) );

	/*
	 * Enable support for WooCommerce.
	 */
	add_theme_support( 'woocommerce' );

	// Set up the WordPress core custom background feature.
	// add_theme_support( 'custom-background', apply_filters( 'mondo_custom_background_args', array(
	// 	'default-color' => 'ffffff',
	// 	'default-image' => '',
	// ) ) );

	/**
	 * Image sizes
	 */
	add_image_size( 'rect_600', 600, 375, true );
	add_image_size( 'rect_1200', 1200, 750, true );

	/**
	 * Enables shortcodes on widgets
	 */
	add_filter( 'widget_text', 'do_shortcode' );
}
endif; // mondo_setup
add_action( 'after_setup_theme', 'mondo_setup' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function mondo_widgets_init() {

	global $mondo_admin_data;
  $footer_column_class = 'col-md-3';
  $footer_column = '4';

  if ( isset( $mondo_admin_data['footer_column'] ) ) {
  	$footer_column = $mondo_admin_data['footer_column'];
  }

  switch ( $footer_column ) {
    case '2':
      $footer_column_class = 'col-md-6';
      break;
    case '3':
      $footer_column_class = 'col-md-4';
      break;
    case '4':
    	$footer_column_class = 'col-md-3';
      break;
    default:
      $footer_column_class = 'col-md-3';
      break;
  }

  register_sidebar( array(
    'name'          => __( 'Footer', 'mondo' ),
    'id'            => 'widget-footer',
    'description'   => '',
    'before_widget' => '<div class="' . esc_attr( $footer_column_class ) . '"><aside id="%1$s" class="widget footer-widget %2$s">',
    'after_widget'  => '</aside></div>',
    'before_title'  => '<h3 class="widget-title"><span>',
    'after_title'   => '</span></h3>'
  ) );
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'mondo' ),
		'id'            => 'widget-sidebar',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title"><span>',
		'after_title'   => '</span></h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Side Menu', 'mondo' ),
		'id'            => 'widget-side-menu',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	if ( class_exists( 'WooCommerce' ) ) {
		register_sidebar( array(
			'name'          => __( 'Shop', 'mondo' ),
			'id'            => 'widget-shop',
			'description'   => '',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		) );
	}
}
add_action( 'widgets_init', 'mondo_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function mondo_scripts() {
	global $mondo_admin_data;

	$protocol = is_ssl() ? 'https' : 'http';
	// wp_enqueue_style( 'mondo-google-fonts', $protocol . '://fonts.googleapis.com/css?family=Roboto:400,500,700|Roboto+Condensed:400,700' );	
	wp_enqueue_style( 'mondo-google-fonts', $protocol . '://fonts.googleapis.com/css?family=Dosis:400,700|Open+Sans:400,600,700' );

	if ( class_exists( 'WooCommerce' ) ) {
		wp_enqueue_style( 'mondo-woocommerce', get_template_directory_uri() . '/css/woocommerce.css', array(), JAY_VERSION );
	}

	wp_enqueue_style( 'mondo-style', get_stylesheet_uri(), array(), JAY_VERSION );

	wp_enqueue_script( 'mondo-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'ie9-fix', get_template_directory_uri() . '/js/ie9-fix.js', array(), JAY_VERSION, true );
	wp_enqueue_script( 'velocity', get_template_directory_uri() . '/js/velocity.min.js', array(), '1.2.2', true );
	wp_enqueue_script( 'pushy', get_template_directory_uri() . '/js/pushy.min.js', array(), '0.9.2', true );
	wp_enqueue_script( 'waves', get_template_directory_uri() . '/js/waves.min.js', array(), '0.6.3', true );
	wp_enqueue_script( 'fitvids', get_template_directory_uri() . '/js/jquery.fitvids.js', array(), '1.1.0', true );
	wp_enqueue_script( 'flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js', array(), '2.4.0', true );
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/js/owl.carousel.min.js', array(), '2.0.0', true );
	wp_enqueue_script( 'retina', get_template_directory_uri() . '/js/retina.min.js', array(), '1.3.0', true );
	wp_enqueue_script( 'enquire', get_template_directory_uri() . '/js/enquire.min.js', array(), '2.1.2', true );
	if ( ! wp_is_mobile() ) {
		wp_enqueue_script( 'skrollr', get_template_directory_uri() . '/js/skrollr.min.js', array(), '0.6.29', true );
		wp_enqueue_script( 'stellar.js', get_template_directory_uri() . '/js/jquery.stellar.min.js', array(), '0.6.2', true );
	}
	wp_enqueue_script( 'js-cookie', get_template_directory_uri() . '/js/js.cookie.js', array(), '1.5.0', true );
	if ( $mondo_admin_data['main_layout'] == 'masonry' || $mondo_admin_data['main_layout'] == 'masonry_right_sidebar' || $mondo_admin_data['main_layout'] == 'masonry_left_sidebar' ) {
		wp_enqueue_script( 'imagesLoaded', get_template_directory_uri() . '/js/imagesloaded.pkgd.min.js', array(), '3.1.8', true );
		wp_enqueue_script( 'isotope', get_template_directory_uri() . '/js/isotope.pkgd.min.js', array(), '2.1.1', true );
		wp_enqueue_script( 'infinite-scroll', get_template_directory_uri() . '/js/jquery.infinitescroll.min.js', array(), '2.1.0', true );
	}
	wp_enqueue_script( 'functions', get_template_directory_uri() . '/js/functions.js', array(), JAY_VERSION, true );

	$mondo_passing_options = array(
		'is_mobile'            => wp_is_mobile(),
		'site_url'             => site_url(),
		'admin_url'            => admin_url( 'admin-ajax.php' ),
		'nonce'                => wp_create_nonce( 'mondo_love_nonce' ),
		'love_title'           => __( 'Click to love this post.', 'mondo' ),
		'unlove_title'         => __( 'You have already loved this post. Click again to unlove it.', 'mondo' ),
		'feature_column'       => $mondo_admin_data['feature_column'],
		'enable_feature_arrow' => $mondo_admin_data['enable_feature_arrow']
	);
	wp_localize_script( 'functions', 'params', $mondo_passing_options );
}
add_action( 'wp_enqueue_scripts', 'mondo_scripts' );

/**
 * TGM Plugin Activation.
 */
require get_template_directory() . '/inc/tgm-plugin-activation/mondo-tgm-config.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Redux framework
 */
if ( ! class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/redux/ReduxCore/framework.php' ) ) {
  require_once( dirname( __FILE__ ) . '/redux/ReduxCore/framework.php' );
}
/**
 * Appends to Redux css
 */
function mondo_append_redux_css() {

  wp_register_style('redux-custom-css', get_template_directory_uri() . '/css/redux-custom.css', array(), time(), 'all');  
  wp_enqueue_style('redux-custom-css');
}
add_action( 'redux/page/mondo_admin_options/enqueue', 'mondo_append_redux_css' );
/**
 * Redux configuration file
 */
require_once( dirname( __FILE__ ) . '/inc/mondo-config.php' );

/**
 * Custom widgets
 */
require get_template_directory() . '/inc/widgets/widgets.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
// require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Custom walker
 */
require get_template_directory() . '/inc/custom-walker.php';

/**
 * Metabox framework
 */
define( 'RWMB_URL', trailingslashit( get_template_directory_uri() . '/inc/meta-box' ) );
define( 'RWMB_DIR', trailingslashit( get_template_directory() . '/inc/meta-box' ) );

require get_template_directory() . '/inc/meta-box/meta-box.php';
require get_template_directory() . '/inc/mondo-metabox.php';

/**
 * WooCommerce custom functions
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/mondo-woocommerce.php';
}
