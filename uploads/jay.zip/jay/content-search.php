<?php
	global $mondo_admin_data;

	$main_layout = $mondo_admin_data['main_layout'];
	$post_class = 'mondo-card';
	$content_class = 'entry-summary mondo-card-content';
	$footer_class = 'entry-footer mondo-card-action';

	if ( $main_layout != 'masonry' ) {
		$post_class = 'mondo-standard';
		$content_class = 'entry-summary';
		$footer_class = 'entry-footer';
	}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?>>
	<div class="<?php echo esc_attr( $content_class ); ?>">
		<header class="entry-header">
			<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>

			<?php if ( 'post' == get_post_type() ) : ?>
			<div class="entry-meta">
				<?php mondo_posted_on(); ?>
			</div><!-- .entry-meta -->
			<?php endif; ?>
		</header><!-- .entry-header -->
		<div class="entry-content">
			<?php the_excerpt(); ?>
		</div>
	</div><!-- .entry-content -->

	<footer class="<?php echo esc_attr( $footer_class ); ?>">
		<?php
			if ( $main_layout == 'masonry' ) {
				mondo_entry_footer();
			} else {
				mondo_entry_footer_standard();
			}
		?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
