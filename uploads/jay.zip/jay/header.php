<?php
	global $mondo_admin_data;

	$main_navigation_style = 'default';
	$main_navigation_class = 'main-navigation';

	if ( isset( $mondo_admin_data['main_navigation_style'] ) ) {
		$main_navigation_style = mondo_compare_options( $mondo_admin_data['main_navigation_style'], rwmb_meta( 'mondo_main_navigation_style' ) );
	}

	if (
		( is_home() && $mondo_admin_data['blog_titlebar_style'] != 'thin' && $mondo_admin_data['blog_titlebar_style'] != 'no' ) ||
		( class_exists( 'WooCommerce' ) && is_shop() && $mondo_admin_data['shop_titlebar_style'] != 'thin' && $mondo_admin_data['shop_titlebar_style'] != 'no' ) ||
		( is_singular() && rwmb_meta( 'mondo_titlebar_style' ) != 'thin' && rwmb_meta( 'mondo_titlebar_style' ) != 'no' && rwmb_meta( 'mondo_titlebar_style' ) != '' ) ||
		( $main_navigation_style == 'default' || $main_navigation_style == 'sticky' )
	) {
		$main_navigation_class .= ' ' . $main_navigation_style;
		$main_navigation_style == 'sticky-transparent' ? $main_navigation_class .= ' transparent' : '';
	} else {
		if ( $main_navigation_style == 'sticky-transparent' ) {
			$main_navigation_class .= ' sticky';

			function mondo_add_navigation_class( $classes ) {

				$classes[] = 'with-sticky-navigation';
				return $classes;
			}
			add_filter( 'body_class', 'mondo_add_navigation_class' );
		} else {
			$main_navigation_class .= ' default';
		}
	}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php
	if ( $mondo_admin_data['disable_preloader'] != '1' ) {
		mondo_preloader();
	}
?>

<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'mondo' ); ?></a>

	<?php if ( $mondo_admin_data['disable_scrollbar'] != '1' ) : ?>
		<div id="scroll-bar">
			<div id="scroll-bar-inner"></div>
		</div>
	<?php endif; ?>

	<header id="masthead" class="site-header" role="banner">
		<nav id="site-navigation" class="<?php echo esc_attr( $main_navigation_class ); ?>" role="navigation">
			<div class="nav-wrapper container">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-logo normal">
					<?php if ( isset( $mondo_admin_data['header_logo'] ) && mondo_redux_image_set( $mondo_admin_data['header_logo'] ) ) : ?>

						<img src="<?php echo esc_url( $mondo_admin_data['header_logo']['url'] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">

					<?php else : ?>

						<span class="text-logo">
							<?php bloginfo( 'name' ); ?>
						</span>

					<?php endif; ?>
				</a>

				<?php if ( isset( $mondo_admin_data['header_logo_contrast'] ) && mondo_redux_image_set( $mondo_admin_data['header_logo_contrast'] ) ) : ?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-logo contrast">
						<img src="<?php echo esc_url( $mondo_admin_data['header_logo_contrast']['url'] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
					</a>
				<?php endif; ?>

				<?php wp_nav_menu( array( 
					'theme_location' => 'primary',
					'container' => false,
					'menu_class' => 'nav-list float-right hidden-xs hidden-sm',
					'walker' => new Mondo_Walker_Nav_Menu(),
					'fallback_cb' => 'Mondo_Walker_Nav_Menu::fallback',
				) ); ?>
				<div class="menu-btn mobile float-right hidden-md hidden-lg">
					<span class="menu-icon-bar"></span>
					<span class="menu-icon-bar"></span>
					<span class="menu-icon-bar"></span>
				</div>
				<?php if ( $mondo_admin_data['enable_search'] == '1' ) : ?>
					<div class="search-btn icon-btn mobile float-right hidden-md hidden-lg">
						<i class="mdi mdi-magnify"></i>
					</div>
				<?php endif; ?>
			</div>
		</nav>

		<?php
			if ( $mondo_admin_data['enable_search'] == '1' ) {
				mondo_search();
			}
		?>
	</header>

	<?php echo get_template_part( 'titlebar' ); ?>

	<?php
		if ( $mondo_admin_data['enable_feature'] == '1' && is_home() ) {
			mondo_featured_posts();
		}
	?>

	<?php echo mondo_mobile_menu(); ?>

	<div class="site-overlay"></div>

	<div id="content" class="site-content container">
		<div class="row">
