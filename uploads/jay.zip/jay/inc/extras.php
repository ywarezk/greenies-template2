<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features
 *
 * @package Jay
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function mondo_body_classes( $classes ) {
	// Adds a class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	global $mondo_admin_data;

	$main_layout = $mondo_admin_data['main_layout'];

	if ( ( $main_layout == 'masonry' || $main_layout == 'masonry_right_sidebar' || $main_layout == 'masonry_left_sidebar' ) && ( is_home() || is_archive() ) ) {
		$classes[] = 'blog-masonry';
	} else if ( $main_layout == 'grid' && is_home() ) {
		$classes[] = 'blog-grid';
	}

	if ( isset( $mondo_admin_data['main_navigation_style'] ) ) {
		$classes[] = 'with-' . esc_attr( $mondo_admin_data['main_navigation_style'] ) . '-navigation';
	}

	return $classes;
}
add_filter( 'body_class', 'mondo_body_classes' );

if ( version_compare( $GLOBALS['wp_version'], '4.1', '<' ) ) :
	/**
	 * Filters wp_title to print a neat <title> tag based on what is being viewed.
	 *
	 * @param string $title Default title text for current view.
	 * @param string $sep Optional separator.
	 * @return string The filtered title.
	 */
	function mondo_wp_title( $title, $sep ) {
		if ( is_feed() ) {
			return $title;
		}

		global $page, $paged;

		// Add the blog name
		$title .= get_bloginfo( 'name', 'display' );

		// Add the blog description for the home/front page.
		$site_description = get_bloginfo( 'description', 'display' );
		if ( $site_description && ( is_home() || is_front_page() ) ) {
			$title .= " $sep $site_description";
		}

		// Add a page number if necessary:
		if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
			$title .= " $sep " . sprintf( __( 'Page %s', 'mondo' ), max( $paged, $page ) );
		}

		return $title;
	}
	add_filter( 'wp_title', 'mondo_wp_title', 10, 2 );

	/**
	 * Title shim for sites older than WordPress 4.1.
	 *
	 * @link https://make.wordpress.org/core/2014/10/29/title-tags-in-4-1/
	 * @todo Remove this function when WordPress 4.3 is released.
	 */
	function mondo_render_title() {
		?>
		<title><?php wp_title( '|', true, 'right' ); ?></title>
		<?php
	}
	add_action( 'wp_head', 'mondo_render_title' );
endif;

/**
 * Generates mobile menu output
 */

function mondo_mobile_menu() {

	global $mondo_admin_data;

	$menu_name = 'primary';

  if ( ( $locations = get_nav_menu_locations() ) && isset( $locations[ $menu_name ] ) ) {
		$menu = wp_get_nav_menu_object( $locations[ $menu_name ] );
		$menu_items = wp_get_nav_menu_items( $menu->term_id );
		$menu_list = '<nav class="pushy pushy-right">';

		$menu_list .= '<a href="#" class="pushy-close"><i class="mdi mdi-close"></i></a>';

		if ( $mondo_admin_data['enable_about'] == '1' ) {
			$menu_list .= mondo_about_me();
		}

		$menu_list .= '<ul class="mobile-menu hidden-md hidden-lg">';
		foreach ( ( array ) $menu_items as $key => $menu_item ) {
	    $title = $menu_item->title;
	    $url = $menu_item->url;
	    $menu_list .= '<li><span class="waves-effect waves-block waves-classic"><a href="' . esc_url( $url ) . '">' . $title . '</a></span></li>';
		}
		$menu_list .= '</ul>';

		$menu_list .= '<div class="side-menu-widget">';

		ob_start();
		dynamic_sidebar( 'widget-side-menu' );
		$sidebar_output = ob_get_clean();
		$menu_list .= $sidebar_output;

		$menu_list .= '</div>';

		$menu_list .= '</nav>';
  } else {
		$menu_list = '<nav class="pushy pushy-right"><ul><li>Menu "' . $menu_name . '" not defined.</li></ul></nav>';
  }

  return $menu_list;
}

/**
 * Customizes password protected form
 */

function mondo_password_protected_form() {

  global $post;
  $label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
  $o = '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post">
  ' . __( "To view this protected post, enter the password below:", 'mondo' ) . '
  <input name="post_password" id="' . $label . '" type="password" placeholder="' . __( "Password:", 'mondo' ) . '" size="20" maxlength="20" /><input type="submit" class="waves-effect waves-button waves-float button-primary" name="Submit" value="' . esc_attr__( "Submit" ) . '" />
  </form>
  ';

  return $o;
}
add_filter( 'the_password_form', 'mondo_password_protected_form' );

/**
 * Adds custom style to <head>
 */

function mondo_custom_style() {

	global $mondo_admin_data;

	$return = '<style type="text/css" class="mondo-custom-css">';

	if (
		( is_home() && $mondo_admin_data['blog_titlebar_style'] != 'thin' && $mondo_admin_data['blog_titlebar_style'] != 'no' ) ||
		( class_exists( 'WooCommerce' ) && is_shop() && $mondo_admin_data['shop_titlebar_style'] != 'thin' && $mondo_admin_data['shop_titlebar_style'] != 'no' ) ||
		( is_singular() && rwmb_meta( 'mondo_titlebar_style' ) != 'thin' && rwmb_meta( 'mondo_titlebar_style' ) != 'no' )
	) {

		// Titlebar background image

		if ( is_home() && isset( $mondo_admin_data['blog_titlebar_image'] ) && mondo_redux_image_set( $mondo_admin_data['blog_titlebar_image'] ) ) {
			$titlebar_image = $mondo_admin_data['blog_titlebar_image']['url'];
		} else if ( is_singular( 'post' ) && has_post_thumbnail() && ( rwmb_meta( 'mondo_titlebar_style' ) == 'wide' || rwmb_meta( 'mondo_titlebar_style' ) == 'full' ) && rwmb_meta( 'mondo_titlebar_image' ) == '' ) {
			$titlebar_image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
			$titlebar_image = $titlebar_image[0];
		} else if ( class_exists( 'WooCommerce' ) && is_shop() && isset( $mondo_admin_data['shop_titlebar_image'] ) && mondo_redux_image_set( $mondo_admin_data['shop_titlebar_image'] ) ) {
			$titlebar_image = $mondo_admin_data['shop_titlebar_image']['url'];
		} else if ( is_search() ) {
			$titlebar_image = '';
		} else {
			$titlebar_image_id = rwmb_meta( 'mondo_titlebar_image' );
			if ( $titlebar_image_id != '' ) {
				$titlebar_image = wp_get_attachment_image_src( $titlebar_image_id, 'full' );
				$titlebar_image = $titlebar_image[0];
			}
		}

		if ( isset( $titlebar_image ) && $titlebar_image != '' ) {
			$return .= '#mondo-titlebar {
				background-image: url("' . esc_url( $titlebar_image ) . '");
			}';
		}

		// Titlebar blurred background image

		if ( is_home() && isset( $mondo_admin_data['blog_titlebar_blur'] ) && mondo_redux_image_set( $mondo_admin_data['blog_titlebar_blur'] ) ) {
			$titlebar_blur = $mondo_admin_data['blog_titlebar_blur']['url'];
		} else if ( class_exists( 'WooCommerce' ) && is_shop() && isset( $mondo_admin_data['shop_titlebar_blur'] ) && mondo_redux_image_set( $mondo_admin_data['shop_titlebar_blur'] ) ) {
			$titlebar_blur = $mondo_admin_data['shop_titlebar_blur']['url'];
		} else if ( is_search() ) {
			$titlebar_blur = '';
		} else {
			$titlebar_blur_id = rwmb_meta( 'mondo_titlebar_blur' );
			if ( $titlebar_blur_id != '' ) {
				$titlebar_blur = wp_get_attachment_image_src( $titlebar_blur_id, 'full' );
				$titlebar_blur = $titlebar_blur[0];
			}
		}

		if ( isset( $titlebar_blur ) && $titlebar_blur != '' ) {
			$return .= '#mondo-titlebar .blur {
				background-image: url("' . esc_url( $titlebar_blur ) . '");
			}';
		}

	}

	if ( isset( $mondo_admin_data['about_me_bg_image'] ) && mondo_redux_image_set( $mondo_admin_data['about_me_bg_image'] ) ) {
		$return .= '
			.pushy .profile,
			.widget_mondo_about_widget .profile { 
				background-image: url("' . esc_url( $mondo_admin_data['about_me_bg_image']['url'] ) . '");
			}
		';
	}

	if ( isset( $mondo_admin_data['primary_color'] ) && mondo_redux_color_set( $mondo_admin_data['primary_color'] ) ) {
		$return .= '
			.mondo-loading-screen .spinner .spinner-element,
			.mondo-bar-preloader .load-bar-base,
			.mondo-bar-preloader .base1 .last,
			.mondo-bar-preloader .base2 .last,
			#mondo-search-fill,
			.main-navigation .nav-list > .menu-item > span > a:hover,
			.main-navigation .sub-menu li a:hover,
			#scroll-bar-inner,
			.pushy .profile,
			.widget_mondo_about_widget .profile,
			#mondo-featured-posts .entry-label,
			.owl-carousel .owl-controls .owl-nav .owl-prev, .owl-carousel .owl-controls .owl-nav .owl-next,
			#secondary .widget .widget-title > span:after,
			#colophon .widget .widget-title > span:after,
			.mondo-card-action .more-links > .list > li a:hover,
			.widget_tag_cloud .tagcloud > a:hover,
			.widget_mondo_categories_widget .category-item-count,
			#mondo-featured-posts .featured-post .mondo-love-button,
			.mondo-card .mondo-love-button,
			.mondo-grid .mondo-love-button,
			#mondo-pagination ul.page-numbers a.page-numbers.current,
			#mondo-pagination ul.page-numbers span.page-numbers.current,
			#mondo-pagination ul.page-numbers a.page-numbers:hover,
			#mondo-pagination ul.page-numbers span.page-numbers:hover,
			.waves-button.button-primary,
			.wpcf7-submit,
			.menu-item-cart .buttons .button.wc-forward,
			.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce .widget_product_search input[type="submit"], .woocommerce.widget_product_search input[type="submit"],
			.woocommerce span.onsale,
			.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
			.woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current,
			#colophon .bottom {
				background-color: ' . esc_html( $mondo_admin_data['primary_color'] ) . ';
			}
		';

		$return .= '
			::selection {
				background-color: ' . esc_html( $mondo_admin_data['primary_color'] ) . ';	
			}
			::-moz-selection {
				background-color: ' . esc_html( $mondo_admin_data['primary_color'] ) . ';	
			}
		';

		$return .= '
			.mejs-controls .mejs-time-rail .mejs-time-current {
				background-color: ' . esc_html( $mondo_admin_data['primary_color'] ) . ' !important;	
			}
		';

		$return .= '
			a:hover, a:focus,
			.mondo-standard .entry-title a:hover,
			.mondo-card .entry-title a:hover,
			#mondo-related-posts .entry-title a:hover,
			.comment-list .comment-author-name .url:hover,
			.menu-item-cart .woocommerce.widget_shopping_cart .cart_list li a:hover,
			.widget_categories .cat-item > a:before {
				color: ' . esc_html( $mondo_admin_data['primary_color'] ) . ';
			}
		';

		$return .= '
			input[type="text"]:focus,
			input[type="password"]:focus,
			input[type="email"]:focus,
			input[type="search"]:focus,
			textarea:focus {
				border-color: ' . esc_html( $mondo_admin_data['primary_color'] ) . ';
			}
		';
	}

	if ( isset( $mondo_admin_data['accent_color'] ) && mondo_redux_color_set( $mondo_admin_data['accent_color'] ) ) {
		$return .= '
			.mondo-bar-preloader .base1 .first,
			.mondo-bar-preloader .base2 .first,
			.menu-item-cart .item-count,
			.mondo-floating-action-button,
      .flex-control-paging li a:hover,
      .flex-control-paging li a.flex-active,
      .widget_mondo_categories_widget .category-item > a:hover .category-item-count,
      .owl-carousel .owl-controls .owl-nav .owl-prev:hover, .owl-carousel .owl-controls .owl-nav .owl-next:hover,
      #mondo-pagination ul.page-numbers a.page-numbers,
      #mondo-pagination ul.page-numbers span.page-numbers,
      .waves-float:hover,
      .wpcf7-submit:hover,
      .menu-item-cart .buttons .button.wc-forward:hover,
      .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce .widget_product_search input[type="submit"]:hover, .woocommerce.widget_product_search input[type="submit"]:hover,
      .woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content,
      .woocommerce nav.woocommerce-pagination ul li a, .woocommerce nav.woocommerce-pagination ul li span,
			div.wpcf7-response-output {
				background-color: ' . esc_html( $mondo_admin_data['accent_color'] ) . ';
			}
		';

		$return .= '
			.mejs-container,
			.mejs-embed,
			.mejs-embed body,
			.mejs-container .mejs-controls {
				background-color: ' . esc_html( $mondo_admin_data['accent_color'] ) . ' !important;	
			}
		';

		$return .= '
			.mondo-card .entry-link .mdi,
			.mondo-card .entry-link a,
			.mondo-standard .entry-link .mdi,
			.mondo-standard .entry-link a,
			.mondo-love-button.loved .mdi,
			#colophon .bottom .social-icons > a:hover {
				color: ' . esc_html( $mondo_admin_data['accent_color'] ) . ';
			}
		';

		$return .= '
			blockquote {
				border-left-color: ' . esc_html( $mondo_admin_data['accent_color'] ) . ';
			}
		';
	}

	if ( is_admin_bar_showing() ) {
		$return .= '.pushy {
			padding-top: 32px;
		}';
		$return .= '.search-close, .pushy-close, #scroll-bar {
			margin-top: 32px;
		}';
		$return .= '@media screen and (max-width:782px) {
			.search-close, .pushy-close, #scroll-bar {
				margin-top: 46px;
			}
		}';
		$return .= '.main-navigation.transparent, .main-navigation.sticky {
			top: 32px;
		}';
		$return .= '@media screen and (max-width:782px) {
			.main-navigation.transparent, .main-navigation.sticky {
				top: 46px;
			}
		}';
	}

	if ( isset( $mondo_admin_data['custom_css'] ) ) {
		$return .= esc_html( $mondo_admin_data['custom_css'] );
	}

	$return .= '</style>';

	echo $return;
}
add_action( 'wp_head', 'mondo_custom_style' );

/**
 * Adds custom items to the menu
 */

function mondo_add_custom_items_to_wp_menu ( $items, $args ) {

	global $mondo_admin_data;

	if ( $args->theme_location === 'primary' ) {

		// Adds a cart widget
		if ( class_exists( 'WooCommerce' ) && $mondo_admin_data['shop_disable_cart'] == '0' ) {
			ob_start();
			the_widget( 'WC_Widget_Cart' );
			$cart_widget = ob_get_clean();

			$items .= '<li class="menu-item menu-item-has-children menu-item-cart">';
			$items .= '
				<span>
					<a href="' . WC()->cart->get_cart_url() . '" class="cart-btn icon-btn">
						<i class="mdi mdi-wallet-travel"></i>
						<span class="item-count">
							' . WC()->cart->cart_contents_count . '
						</span>
					</a>
				</span>
				<ul class="sub-menu">
					<li class="menu-item">' . $cart_widget . '</li>
				</ul>
			';
			$items .= '</li>';
		}

		// Adds a search toggle
		if ( $mondo_admin_data['enable_search'] == '1' ) {
			$items .= '<li class="menu-item menu-item-search">';
			$items .= '
				<span>
					<a class="search-btn icon-btn">
						<i class="mdi mdi-magnify"></i>
					</a>
				</span>';
			$items .= '</li>';
		}

		// Adds a hamburger menu
		if ( $mondo_admin_data['enable_sidemenu'] == '1' ) {
			$items .= '<li class="menu-item menu-item-hamburger hidden-sm hidden-xs">';
			$items .= '
				<span>
					<a class="menu-btn icon-btn">
						<span class="menu-icon-bar"></span>
						<span class="menu-icon-bar"></span>
						<span class="menu-icon-bar"></span>
					</a>
				</span>';
			$items .= '</li>';
		}

	}

	return $items;
}
add_filter( 'wp_nav_menu_items', 'mondo_add_custom_items_to_wp_menu', 10, 2 );

/**
 * Returns Instagram user ID based on username
 */

function get_instagram_user_id( $username, $token ) {

	$username = strtolower( $username );

	if ( ( $response = get_transient( 'mondo_instagram_user_id' ) ) === false ) {
		$response = wp_remote_get( 'https://api.instagram.com/v1/users/search?q=' . $username . '&access_token=' . $token,
			array(
				'sslverify' => apply_filters( 'https_local_ssl_verify', false )
			)
		);
		
		set_transient( 'mondo_instagram_user_id', $response, 5 * MINUTE_IN_SECONDS );
	}

	$json = json_decode( $response['body'] );

	foreach( $json->data as $user ) {
		if( $user->username == $username ) {
			return $user->id;
		}
	}

	return '00000000'; // return this if nothing is found
}

/**
 * Checks if Redux image field is set with an image
 */

function mondo_redux_image_set( $field ) {

	return ( is_array( $field ) && $field['url'] != '' );
}

/**
 * Checks if Redux text field is set
 */

function mondo_redux_text_set( $field ) {

	return ( $field != '' );
}

/**
 * Checks if Redux color field is set
 */

function mondo_redux_color_set( $field ) {

	return ( $field != '' );
}

/**
 * Compares two option values, and decides which one to return
 */

function mondo_compare_options( $global, $override, $special = null ) {

	if ( $global == $override || $override == '' || ( ! is_null( $special ) && $override == $special ) || is_search() ) {
		return $global;
	} else {
		return $override;
	}
}

/**
 * Ajaxify WooCommerce cart count on the menu
 */

function mondo_ajax_cart_count( $fragments ) {

	ob_start(); ?>

  <span class="item-count"><?php echo WC()->cart->cart_contents_count; ?></span>

  <?php

	$fragments['span.item-count'] = ob_get_clean();

	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'mondo_ajax_cart_count' );

/**
 * Adds social network links to author's contact info
 */

function mondo_add_links_to_author_profile( $contactmethods ) {
	
	$contactmethods['facebook_url'] = __( 'Facebook URL', 'mondo' );
	$contactmethods['twitter_url'] = __( 'Twitter URL', 'mondo' );
	$contactmethods['instagram_url'] = __( 'Instagram URL', 'mondo' );
	$contactmethods['google_plus_url'] = __( 'Google+ URL', 'mondo' );
	$contactmethods['linkedin_url'] = __( 'LinkedIn URL', 'mondo' );
	
	return $contactmethods;
}
add_filter( 'user_contactmethods', 'mondo_add_links_to_author_profile', 10, 1 );

/**
 * Adds "Love It" functionality to blog posts
 */

function mondo_love_it() {

	$nonce = $_POST['nonce'];

  if ( ! wp_verify_nonce( $nonce, 'mondo_love_nonce' ) ) {
  	die( 'BUSTED!' );
  }

  $post_id = $_POST['post_id'];
  $current_count = get_post_meta( $post_id, 'mondo_love', true );
  if ( $current_count == '' ) {
  	$current_count = 0;
  }

  $updated_count = $current_count + 1;
  update_post_meta( $post_id, 'mondo_love', $updated_count );

  die( (string) $updated_count );
}
add_action( 'wp_ajax_mondo_love', 'mondo_love_it' );
add_action( 'wp_ajax_nopriv_mondo_love', 'mondo_love_it' );

/**
 * Adds "Unlove It" functionality to blog posts
 */

function mondo_unlove_it() {

	$nonce = $_POST['nonce'];

  if ( ! wp_verify_nonce( $nonce, 'mondo_love_nonce' ) ) {
  	die( 'BUSTED!' );
  }

  $post_id = $_POST['post_id'];
  $current_count = get_post_meta( $post_id, 'mondo_love', true );

  // Makes sure love count is equal to 0 or more than 0
  if ( $current_count == '' || $current_count == '0' ) {
  	$current_count = 1;
  }

  $updated_count = $current_count - 1;

  if ( $updated_count >= 0 ) {
	  update_post_meta( $post_id, 'mondo_love', $updated_count );
	}

  die( (string) $updated_count );
}
add_action( 'wp_ajax_mondo_unlove', 'mondo_unlove_it' );
add_action( 'wp_ajax_nopriv_mondo_unlove', 'mondo_unlove_it' );

/**
 * Changes excerpt length
 */

function mondo_custom_excerpt_length( $length ) {

	global $mondo_admin_data;

	return esc_html( $mondo_admin_data['excerpt_length'] );
}
add_filter( 'excerpt_length', 'mondo_custom_excerpt_length', 999 );

/**
 * Custom archive title
 */

function mondo_custom_archive_title( $title ) {

	if ( is_category() ) {
	  $title = single_cat_title( '', false );
  } else if ( is_tag() ) {
  	$title = single_tag_title( '', false );
  }

  return $title;
}
add_filter( 'get_the_archive_title', 'mondo_custom_archive_title' );