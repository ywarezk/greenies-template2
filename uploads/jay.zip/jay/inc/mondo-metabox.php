<?php
/**
 * Registering meta boxes
 *
 * All the definitions of meta boxes are listed below with comments.
 * Please read them CAREFULLY.
 *
 * You also should read the changelog to know what has been changed before updating.
 *
 * For more information, please visit:
 * @link http://metabox.io/docs/registering-meta-boxes/
 */

/**
 * Register meta boxes
 *
 * Remember to change "your_prefix" to actual prefix in your project
 *
 * @param array $meta_boxes List of meta boxes
 *
 * @return array
 */
function mondo_register_meta_boxes( $meta_boxes ) {
	/**
	 * prefix of meta keys (optional)
	 * Use underscore (_) at the beginning to make keys hidden
	 * Alt.: You also can make prefix empty to disable it
	 */
	// Better has an underscore as last sign
	$prefix = 'mondo_';

	$meta_boxes[] = array(
		'id' => 'blog_settings',
		'title' => __( 'Post Format Settings', 'mondo' ),
		'pages' => array( 'post' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'type' => 'heading',
				'name' => __( 'Image Format', 'mondo' ),
				'id'   => 'heading_id',
			),
			array(
				'name'             => __( 'Image', 'mondo' ),
				'id'               => "{$prefix}pf_image_data",
				'type'             => 'image_advanced',
				'max_file_uploads' => 1,
			),
			array(
				'type' => 'heading',
				'name' => __( 'Video Format', 'mondo' ),
				'id'   => 'heading_id',
			),
			array(
				'name' => __( 'Video Embed', 'mondo' ),
				'id'   => "{$prefix}pf_video_data",
				'type' => 'textarea',
				'cols' => 20,
				'rows' => 4,
			),
			array(
				'type' => 'heading',
				'name' => __( 'Gallery Format', 'mondo' ),
				'id'   => 'heading_id',
			),
			array(
				'name'             => __( 'Gallery Images', 'mondo' ),
				'id'               => "{$prefix}pf_gallery_data",
				'type'             => 'image_advanced',
				'max_file_uploads' => 10,
			),
			array(
				'type' => 'heading',
				'name' => __( 'Quote Format', 'mondo' ),
				'id'   => 'heading_id',
			),
			array(
				'name'  => __( 'Source Name', 'mondo' ),
				'id'    => "{$prefix}pf_quote_source",
				'type'  => 'text',
			),
			array(
				'name' => __( 'Source URL', 'mondo' ),
				'id'   => "{$prefix}pf_quote_url",
				'type' => 'url',
			),
			array(
				'type' => 'heading',
				'name' => __( 'Link Format', 'mondo' ),
				'id'   => 'heading_id',
			),
			array(
				'name'  => __( 'Link Text', 'mondo' ),
				'id'    => "{$prefix}pf_link_text",
				'type'  => 'text',
			),
			array(
				'name' => __( 'Link URL', 'mondo' ),
				'id'   => "{$prefix}pf_link_url",
				'type' => 'url',
			),
			array(
				'type' => 'heading',
				'name' => __( 'Audio Format', 'mondo' ),
				'id'   => 'heading_id',
			),
			array(
				'name' => __( 'Audio Embed', 'mondo' ),
				'id'   => "{$prefix}pf_audio_data",
				'type' => 'textarea',
				'cols' => 20,
				'rows' => 4,
			),
		)
	);

	$meta_boxes[] = array(
		'id' => 'layout_settings',
		'title' => __( 'Layout Settings', 'mondo' ),
		'pages' => array( 'post', 'page' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name'     => __( 'Layout', 'mondo' ),
				'id'       => "{$prefix}single_layout",
				'type'     => 'select',
				'options'  => array(
					'with_sidebar' => __( 'With Sidebar', 'mondo' ),
					'full_width' => __( 'Full Width', 'mondo' ),
				),
				'multiple' => false,
				'std'      => 'with_sidebar',
			),
		)
	);

	$titlebar_default_value = 'no';
	if ( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'page' ) {
		$titlebar_default_value = 'thin';
	}

	$meta_boxes[] = array(
		'id' => 'titlebar_settings',
		'title' => __( 'Titlebar Settings', 'mondo' ),
		'pages' => array( 'post', 'page' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name'     => __( 'Titlebar', 'mondo' ),
				'id'       => "{$prefix}titlebar_style",
				'type'     => 'select',
				'options'  => array(
					'no' => __( 'No Titlebar', 'mondo' ),
					'thin' => __( 'Thin Titlebar', 'mondo' ),
					'wide' => __( 'Wide Titlebar', 'mondo' ),
					'full' => __( 'Full Titlebar', 'mondo' ),
				),
				'multiple' => false,
				'std'      => $titlebar_default_value,
			),
			array(
				'name'  => __( 'Title', 'mondo' ),
				'id'    => "{$prefix}titlebar_title",
				'type'  => 'text',
				'desc' => __( 'If you fill this field, it will override page title', 'mondo' ),
			),
			array(
				'name'  => __( 'Subtitle', 'mondo' ),
				'id'    => "{$prefix}titlebar_subtitle",
				'type'  => 'text',
			),
			array(
				'name' => __( 'Background Image', 'mondo' ),
				'id'   => "{$prefix}titlebar_image",
				'type' => 'image_advanced',
				'max_file_uploads' => 1,
				'desc' => __( 'Please note that background image does not work on thin titlebar', 'mondo' ),
			),
			array(
				'name' => __( 'Blurred Background Image', 'mondo' ),
				'id'   => "{$prefix}titlebar_blur",
				'type' => 'image_advanced',
				'max_file_uploads' => 1,
				'desc' => __( 'Please note that background image does not work on thin titlebar', 'mondo' ),
			),
		)
	);

	$meta_boxes[] = array(
		'id' => 'feature_settings',
		'title' => __( 'Featured Post', 'mondo' ),
		'pages' => array( 'post' ),
		'context' => 'side',
		'priority' => 'low',
		'autosave' => true,
		'fields' => array(
			array(
				'name'  => __( 'Feature this post?', 'mondo' ),
				'id'    => "{$prefix}featured_post",
				'type'  => 'checkbox',
				'std'   => 0,
			),
			array(
				'name'  => __( 'Post Label', 'mondo' ),
				'id'    => "{$prefix}featured_post_label",
				'type'  => 'text',
				'desc'  => __( 'Displays a label in left top corner of a post.', 'mondo' ),
			),
		)
	);

	$meta_boxes[] = array(
		'id' => 'main_navigation_settings',
		'title' => __( 'Main Navigation Settings', 'mondo' ),
		'pages' => array( 'post', 'page' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name'     => __( 'Style', 'mondo' ),
				'id'       => "{$prefix}main_navigation_style",
				'type'     => 'select',
				'options'  => array(
					'default' => __( 'Default', 'mondo' ),
					'transparent' => __( 'Transparent', 'mondo' ),
					'sticky' => __( 'Sticky', 'mondo' ),
					'sticky-transparent' => __( 'Sticky + Transparent', 'mondo' ),
				),
				'multiple' => false,
				'placeholder' => __( 'Select an Item', 'mondo' )
			),
		)
	);

	$meta_boxes[] = array(
		'id' => 'sharer_settings',
		'title' => __( 'Sharer Settings', 'mondo' ),
		'pages' => array( 'post' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name'     => __( 'Disable sharer?', 'mondo' ),
				'id'       => "{$prefix}disable_sharer",
				'type'     => 'select',
				'options'  => array(
					'2' => __( 'Select an Item', 'mondo' ),
					'1' => __( 'Yes', 'mondo' ),
					'0' => __( 'No', 'mondo' ),
				),
				'multiple'    => false,
				'std'         => '2',
			),
		)
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'mondo_register_meta_boxes' );
