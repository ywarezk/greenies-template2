<?php
	global $mondo_admin_data;

	$post_class = 'mondo-card';
	$main_layout = $mondo_admin_data['main_layout'];

	$post_format = get_post_format();
	$post_format == '' ? $post_format = 'standard' : '';
	
	$main_layout == 'masonry' ? $column_class = 'col-md-4 col-sm-6' : $column_class = 'col-md-6 col-sm-6';

	$isotope_class = $column_class . ' isotope-item isotope-item-' . $post_format;
?>

<div class="<?php echo esc_attr( $isotope_class ); ?>">

	<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?>>
		<?php if ( has_post_thumbnail() ) : ?>
			<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
				<div class="mondo-card-media waves-effect waves-light waves-block">
					<?php the_post_thumbnail( 'rect_600' ); ?>
				</div>
			</a>
		<?php endif; ?>

		<div class="entry-content mondo-card-content">
			<?php mondo_love_link( false, false ); ?>
			<header class="entry-header">
				<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>

				<?php if ( 'post' == get_post_type() ) : ?>
				<div class="entry-meta">
					<?php mondo_posted_on( true ); ?>
				</div><!-- .entry-meta -->
				<?php endif; ?>
			</header><!-- .entry-header -->

			<?php if ( rwmb_meta( 'mondo_pf_link_text' ) != '' ) : ?>
				<div class="entry-link">
					<i class="mdi mdi-link"></i>			
					<a href="<?php echo esc_url( rwmb_meta( 'mondo_pf_link_url' ) ); ?>">
						<?php echo rwmb_meta( 'mondo_pf_link_text' ); ?>
					</a>
				</div>
			<?php endif; ?>

			<?php the_excerpt(); ?>

			<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'mondo' ),
					'after'  => '</div>',
				) );
			?>
		</div><!-- .entry-content -->

		<footer class="entry-footer mondo-card-action">
			<?php mondo_entry_footer(); ?>
		</footer><!-- .entry-footer -->
	</article><!-- #post-## -->

</div>
