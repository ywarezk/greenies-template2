<?php
	global $mondo_admin_data;

	$post_class = 'mondo-grid';
	$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'rect_600' );
	$css = 'background-image: url(' . $bg_image[0] . ');';
?>

<div class="col-md-4 col-sm-6">
	<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?> style="<?php echo esc_attr( $css ); ?>">
		<div class="mondo-grid-mask">
			<div class="entry-content mondo-grid-content">
				<header class="entry-header">
					<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
				</header>
				<footer class="entry-footer mondo-grid-footer">
					<?php mondo_entry_footer_slim(); ?>
				</footer><!-- .entry-footer -->
			</div>

			<?php mondo_love_link( false, false ); ?>
		</div>
	</article><!-- #post-## -->
</div>
