<?php
	global $mondo_admin_data;

	$post_class = 'mondo-standard';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?>>
	<?php if ( rwmb_meta( 'mondo_pf_video_data' ) != '' ) : ?>
		<div class="entry-media">
			<div class="mondo-video-wrapper">
				<?php echo rwmb_meta( 'mondo_pf_video_data' ); ?>
			</div>
		</div>
	<?php endif; ?>

	<header class="entry-header">
		<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>

		<?php mondo_entry_meta_standard(); ?>
	</header><!-- .entry-header -->
	
	<div class="entry-content">
		<?php
			if ( $mondo_admin_data['post_content'] == 'content' ) {
				the_content();
			} else {
				the_excerpt();
			}
		?>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'mondo' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php mondo_entry_footer_standard(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
