<?php
	global $mondo_admin_data;

	$post_class = 'mondo-standard';
	$main_layout = $mondo_admin_data['main_layout'];
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?>>
	<?php if ( rwmb_meta( 'mondo_pf_image_data' ) != '' ) : ?>
		<?php if ( $main_layout == 'parallax' ) : ?>

			<?php $image_src = wp_get_attachment_image_src( rwmb_meta( 'mondo_pf_image_data' ), 'full' ); ?>
			<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
				<div class="entry-media mondo-parallax" data-stellar-background-ratio="0.2" style="background-image: url(<?php echo esc_url( $image_src[0] ); ?>)"></div>
			</a>

		<?php else : ?>

			<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
				<div class="entry-media waves-effect waves-light waves-block">
					<?php echo wp_get_attachment_image( rwmb_meta( 'mondo_pf_image_data' ), 'full' ); ?>
				</div>
			</a>

		<?php endif; ?>
	<?php endif; ?>
	
	<header class="entry-header">
		<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>

		<?php mondo_entry_meta_standard(); ?>
	</header><!-- .entry-header -->
	
	<div class="entry-content">
		<?php
			if ( $mondo_admin_data['post_content'] == 'content' ) {
				the_content();
			} else {
				the_excerpt();
			}
		?>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'mondo' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php mondo_entry_footer_standard(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
