<?php
	global $mondo_admin_data;

	$post_class = 'mondo-standard';
	$main_layout = $mondo_admin_data['main_layout'];
	$thumbnail_url = wp_get_attachment_url( get_post_thumbnail_id() );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<?php if ( $main_layout == 'parallax' ) : ?>

			<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
				<div class="entry-media mondo-parallax" data-stellar-background-ratio="0.2" style="background-image: url(<?php echo esc_url( $thumbnail_url ); ?>)"></div>
			</a>

		<?php else : ?>

			<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
				<div class="entry-media waves-effect waves-light waves-block">
					<?php the_post_thumbnail( 'full' ); ?>
				</div>
			</a>

		<?php endif; ?>
	<?php endif; ?>

	<header class="entry-header">
		<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>

		<?php mondo_entry_meta_standard(); ?>
	</header><!-- .entry-header -->
	
	<div class="entry-content">
		<?php
			/* translators: %s: Name of current post */
			the_content( sprintf(
				__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'mondo' ),
				the_title( '<span class="screen-reader-text">"', '"</span>', false )
			) );
		?>

		<?php if ( rwmb_meta( 'mondo_pf_quote_source' ) != '' ) : ?>
			<a href="<?php echo esc_url( rwmb_meta( 'mondo_pf_quote_url' ) ); ?>">
				<?php echo '- ' . rwmb_meta( 'mondo_pf_quote_source' ); ?>
			</a>
		<?php endif; ?>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'mondo' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php mondo_entry_footer_standard(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
