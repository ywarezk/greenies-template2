<?php
	global $mondo_admin_data;

	$post_class = 'mondo-standard';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $post_class ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
			<div class="entry-media waves-effect waves-light waves-block">
				<?php the_post_thumbnail(); ?>
			</div>
		</a>
	<?php endif; ?>

	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<?php mondo_entry_meta_standard(); ?>
	</header><!-- .entry-header -->
	
	<div class="entry-content">
		<?php if ( rwmb_meta( 'mondo_pf_link_text' ) != '' ) : ?>
			<div class="entry-link">
				<i class="mdi mdi-link"></i>			
				<a href="<?php echo esc_url( rwmb_meta( 'mondo_pf_link_url' ) ); ?>">
					<?php echo rwmb_meta( 'mondo_pf_link_text' ); ?>
				</a>
			</div>
		<?php endif; ?>

		<?php
			the_content();
			
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'mondo' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php mondo_entry_footer_standard(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
