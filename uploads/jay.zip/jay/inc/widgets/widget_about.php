<?php

/**
 * Adds About widget.
 */

class Mondo_About_Widget extends WP_Widget {

	function __construct() {
		
		parent::__construct(
			'mondo_about_widget', // Base ID
			__('Mondo: About', 'mondo'), // Name
			array( 'description' => __( 'Displays about the author.', 'mondo' ), ) // Args
		);
	}

	public function widget( $args, $instance ) {

		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );

		$return = null;

		echo $before_widget;
		if ( ! empty( $title ) ) {
			echo $before_title . $title . $after_title;
		}

		global $mondo_admin_data;

		ob_start(); ?>

		<div class="profile">
			<?php if ( isset( $mondo_admin_data['profile_image'] ) && mondo_redux_image_set( $mondo_admin_data['profile_image'] ) ) : ?>
				<div class="profile-content">
					<img src="<?php echo esc_url( $mondo_admin_data['profile_image']['url'] ); ?>" class="profile-image img-circle" alt="<?php echo esc_attr( $mondo_admin_data['profile_name'] ); ?>">
					<div class="profile-name">
						<?php
							if ( isset( $mondo_admin_data['profile_name'] ) && mondo_redux_text_set( $mondo_admin_data['profile_name'] ) ) {
								echo esc_html( $mondo_admin_data['profile_name'] );
							}
						?>
					</div>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( isset( $mondo_admin_data['about_me_text'] ) && mondo_redux_text_set( $mondo_admin_data['about_me_text'] ) ) : ?>
			<div class="about-me">
				<?php echo wp_kses( $mondo_admin_data['about_me_text'], array(
					'a'      => array( 'href' => array() ),
					'span'   => array( 'style' => array() ),
					'i'      => array( 'class' => array(), 'style' => array() ),
					'em'     => array(),
					'strong' => array()
				) ); ?>
			</div>
		<?php endif; ?>

		<?php

		echo ob_get_clean();

		echo $after_widget;
	}

	public function form( $instance ) {

		$defaults = array( 'title' => 'About' );
		$instance = wp_parse_args( (array) $instance, $defaults );

		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Title:', 'mondo' ); ?></label> 
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>
		<?php 
	}

	public function update( $new_instance, $old_instance ) {

		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

		return $instance;
	}

}
