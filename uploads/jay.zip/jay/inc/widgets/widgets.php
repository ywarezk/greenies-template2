<?php

require_once( get_template_directory() . '/inc/widgets/widget_facebook.php' );
require_once( get_template_directory() . '/inc/widgets/widget_instagram.php' );
require_once( get_template_directory() . '/inc/widgets/widget_flickr.php' );
require_once( get_template_directory() . '/inc/widgets/widget_dribbble.php' );
require_once( get_template_directory() . '/inc/widgets/widget_recent-posts.php' );
require_once( get_template_directory() . '/inc/widgets/widget_most-loved-posts.php' );
require_once( get_template_directory() . '/inc/widgets/widget_most-commented-posts.php' );
require_once( get_template_directory() . '/inc/widgets/widget_about.php' );
require_once( get_template_directory() . '/inc/widgets/widget_categories.php' );

function register_widgets() {
  register_widget( 'Mondo_Facebook_Widget' );
  register_widget( 'Mondo_Instagram_Widget' );
  register_widget( 'Mondo_Flickr_Widget' );
  register_widget( 'Mondo_Dribbble_Widget' );
  register_widget( 'Mondo_Recent_Posts_Widget' );
  register_widget( 'Mondo_Most_Loved_Posts_Widget' );
  register_widget( 'Mondo_Most_Commented_Posts_Widget' );
  register_widget( 'Mondo_About_Widget' );
  register_widget( 'Mondo_Categories_Widget' );
}
add_action( 'widgets_init', 'register_widgets' );