<?php

/**
 * Adds Most Loved Posts widget.
 */

class Mondo_Most_Loved_Posts_Widget extends WP_Widget {

	function __construct() {
		
		parent::__construct(
			'mondo_most_loved_posts_widget', // Base ID
			__('Mondo: Most Loved Posts', 'mondo'), // Name
			array( 'description' => __( 'Displays Most Loved Posts.', 'mondo' ), ) // Args
		);
	}

	public function widget( $args, $instance ) {

		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		$count = $instance['count'];

		$return = null;

		echo $before_widget;
		if ( ! empty( $title ) ) {
			echo $before_title . $title . $after_title;
		}

		$args = array( 
			'numberposts' => $count,
			'post_status' => 'publish',
			'meta_key' => 'mondo_love',
			'orderby' => 'meta_value_num',
			'meta_query' => array(
				'meta_key' => 'mondo_love',
				'meta_value' => '0',
				'meta_compare' => '>'
			)
		);
		$recent_posts = wp_get_recent_posts( $args );

		$return .= '<ul class="post-widget-list">';

		foreach ( $recent_posts as $recent ) {
			$love_count = get_post_meta( $recent['ID'], 'mondo_love', true );

			$return .= '<li class="clearfix">';
			$return .= '<a href="' . esc_url( get_permalink( $recent['ID'] ) ) . '" class="thumbnail-link" rel="bookmark">';
			$return .= '<span class="thumbnail-container float-left">';
			$return .= get_the_post_thumbnail( $recent['ID'], 'thumbnail', array( 'class' => 'opacity-element' ) );
			$return .= '</span>';
			$return .= '</a>';
			$return .= '<div class="entry-content">';
			$return .= '<h4 class="entry-title">';
			$return .= '<a href="' . esc_url( get_permalink( $recent['ID'] ) ) . '" rel="bookmark">' . esc_html( $recent['post_title'] ) . '</a>';
			$return .= '</h4>';
			$return .= '<span class="entry-meta">' . sprintf( _n( '%d love', '%d loves', esc_html( $love_count ), 'mondo' ), esc_html( $love_count ), esc_html( $love_count ) ) . '</span>';
			$return .= '</div>';
			$return .= '</li>';
		}

		$return .= '</ul>';	

		echo $return;

		echo $after_widget;
	}

	public function form( $instance ) {

		$defaults = array( 'title' => 'Most Loved Posts', 'count' => '6' );
		$instance = wp_parse_args( (array) $instance, $defaults );

		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Title:', 'mondo' ); ?></label> 
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php _e( 'Count:', 'mondo' ); ?></label> 
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['count'] ); ?>" />
		</p>
		<?php 
	}

	public function update( $new_instance, $old_instance ) {

		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['count'] = ( ! empty( $new_instance['count'] ) ) ? strip_tags( $new_instance['count'] ) : '';

		return $instance;
	}

}
