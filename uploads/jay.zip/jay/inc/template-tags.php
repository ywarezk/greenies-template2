<?php

if ( ! function_exists( 'mondo_media_feed' ) ) :
function mondo_media_feed() {

	global $mondo_admin_data;

	$type = esc_html( $mondo_admin_data['media_feed_type'] );
	$feed_class = 'instagram container';

	if ( $type == 'instagram' ) {
		$return = mondo_media_feed_instagram();
	} else {
		$return = mondo_media_feed_dribbble();
		$feed_class = 'dribbble container';
	} ?>
	
	<div id="mondo-media-feed" class="<?php echo esc_attr( $feed_class ); ?>">
		<div class="thumbnails">
			<?php echo $return; ?>
		</div>
	</div>

	<?php
}
endif;

if ( ! function_exists( 'mondo_media_feed_instagram' ) ) :
function mondo_media_feed_instagram() {

	global $mondo_admin_data;
	$return = '';

	if ( get_theme_mod( 'instagram_access_token' ) ) {

		$user_id = get_theme_mod( 'instagram_user_id' );
  	if ( isset( $mondo_admin_data['instagram_username'] ) && $mondo_admin_data['instagram_username'] != '' ) {
  		$user_id = get_instagram_user_id( $mondo_admin_data['instagram_username'], get_theme_mod( 'instagram_access_token' ) );
  	}

  	if ( ( $response = get_transient( 'mondo_media_feed_instagram' ) ) === false ) {
  		$response = wp_remote_get( 'https://api.instagram.com/v1/users/' . $user_id . '/media/recent/?access_token=' . get_theme_mod( 'instagram_access_token' ) . '&count=7',
				array(
					'sslverify' => apply_filters( 'https_local_ssl_verify', false )
				)
			);

			set_transient( 'mondo_media_feed_instagram', $response, 5 * MINUTE_IN_SECONDS );
  	}

		if ( ! is_wp_error( $response ) ) {

			$instagram_feed = json_decode( $response['body'] );
			$main_data = array();
			$n = 0;

			if ( $instagram_feed->meta->code < 400 ) {
				foreach ( $instagram_feed->data as $d ) {
					$main_data[ $n ]['thumbnail'] = $d->images->standard_resolution->url;
					$main_data[ $n ]['link'] = $d->link;
					if ( isset( $d->caption->text ) ) {
						$main_data[ $n ]['caption'] = $d->caption->text;
					} else {
						$main_data[ $n ]['caption'] = '';
					}
					$n++;
				}

				$n = 1;
				
				foreach ( $main_data as $data ) {
					$return .= '<a href="' . esc_url( $data['link'] ) . '" class="thumbnail thumbnail-' . esc_attr( $n ) . '" target="_blank" title="' . esc_attr( $data['caption'] ) . '">';
					$return .= '<span class="thumbnail-inner waves-effect waves-light waves-block">';
					$return .= '<img src="' . esc_url( $data['thumbnail'] ) . '" alt="' . esc_attr( $data['caption'] ) . '">';
					$return .= '</span>';
					$return .= '</a>';
					$n++;
				}
			}

		}
	} else {
		$return = __( 'Please, configure Instagram settings in Social Media section of Jay Options on your WordPress admin panel.', 'mondo' );
	}

	return $return;
}
endif;

if ( ! function_exists( 'mondo_media_feed_dribbble' ) ) :
function mondo_media_feed_dribbble() {

	global $mondo_admin_data;
	$return = '';

	if ( isset( $mondo_admin_data['dribbble_access_token'] ) && $mondo_admin_data['dribbble_access_token'] != '' && isset( $mondo_admin_data['dribbble_username'] ) && $mondo_admin_data['dribbble_username'] != '' ) {

		$access_token = $mondo_admin_data['dribbble_access_token'];
		$username = $mondo_admin_data['dribbble_username'];

  	if ( ( $response = get_transient( 'mondo_media_feed_dribbble' ) ) === false ) {
  		$response = wp_remote_get( 'https://api.dribbble.com/v1/users/' . $username . '/shots?access_token=' . $access_token . '&per_page=7',
  			array(
					'sslverify' => apply_filters( 'https_local_ssl_verify', false )
				)
  		);
  		
			set_transient( 'mondo_media_feed_dribbble', $response, 5 * MINUTE_IN_SECONDS );
  	}

		if ( ! is_wp_error( $response ) ) {

			$dribbble_feed = json_decode( $response['body'] );
			$main_data = array();
			$n = 0;

			if ( $dribbble_feed ) {
				foreach ( $dribbble_feed as $d ) {
					if ( $n == 2 && ! is_null( $d->images->hidpi ) ) {
						$main_data[ $n ]['src'] = $d->images->hidpi;
					} else {
						$main_data[ $n ]['src'] = $d->images->normal;
					}
					$main_data[ $n ]['link'] = $d->html_url;
					if ( isset( $d->title ) ) {
						$main_data[ $n ]['title'] = $d->title;
					} else {
						$main_data[ $n ]['title'] = '';
					}
					$n++;
				}

				$n = 1;

				foreach ( $main_data as $data ) {
					$return .= '<a href="' . esc_url( $data['link'] ) . '" class="thumbnail thumbnail-' . esc_attr( $n ) . '" target="_blank" title="' . esc_attr( $data['title'] ) . '">';
					$return .= '<span class="thumbnail-inner waves-effect waves-light waves-block">';
					$return .= '<img src="' . esc_url( $data['src'] ) . '" alt="' . esc_attr( $data['title'] ) . '">';
					$return .= '</span>';
					$return .= '</a>';
					$n++;
				}
			}

		}

	} else {
		$return = __( 'Please, enter Dribbble access token and username in Social Media section of Jay Options on your WordPress admin panel.', 'mondo' );
	}

	return $return;
}
endif;

if ( ! function_exists( 'mondo_pagination' ) ) :
function mondo_pagination() {

	global $mondo_admin_data;
	
	$prev_arrow = is_rtl() ? '<i class="mdi mdi-chevron-right"></i>' : '<i class="mdi mdi-chevron-left"></i>';
	$next_arrow = is_rtl() ? '<i class="mdi mdi-chevron-left"></i>' : '<i class="mdi mdi-chevron-right"></i>';
	
	global $wp_query;
	$total = $wp_query->max_num_pages;
	$big = 999999999; // need an unlikely integer
	if ( $total > 1 ) {
		if ( ! $current_page = get_query_var( 'paged' ) )
			$current_page = 1;
		if ( get_option( 'permalink_structure' ) ) {
			$format = 'page/%#%/';
		} else {
			$format = '&paged=%#%';
		}
		if ( $mondo_admin_data['main_layout'] == 'grid' ) {
			echo '<div id="mondo-pagination" class="text-center">';
		} else {
			echo '<div id="mondo-pagination">';
		}
		echo paginate_links( array(
			'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format'    => $format,
			'current'   => max( 1, get_query_var( 'paged' ) ),
			'total'     => $total,
			'mid_size'  => 3,
			'type'      => 'list',
			'prev_text' => $prev_arrow,
			'next_text' => $next_arrow,
		) );
		echo '</div>';
	}
}
endif;

if ( ! function_exists( 'mondo_about_author' ) ) :
function mondo_about_author() { ?>
	
	<div id="mondo-about-author" class="clearfix">
		<div class="author-image">
			<?php echo get_avatar( get_the_author_meta( 'email' ), '90', null, get_the_author_meta( 'display_name' ) ); ?>
		</div>
		<div class="author-info">
			<h4 class="author-title"><?php the_author_link(); ?></h4>
			<p class="author-description"><?php the_author_meta( 'description' ); ?></p>
			<ul class="author-social-links">
				<?php
					$facebook_url = get_the_author_meta( 'facebook_url' );
					if ( isset( $facebook_url ) && $facebook_url != '' ) {
						echo '<li class="facebook">' . '<a href="' . esc_url( $facebook_url ) . '">' . '<i class="mdi mdi-facebook-box"></i>' . '</a></li>';
					}
					$twitter_url = get_the_author_meta( 'twitter_url' );
					if ( isset( $twitter_url ) && $twitter_url != '' ) {
						echo '<li class="twitter">' . '<a href="' . esc_url( $twitter_url ) . '">' . '<i class="mdi mdi-twitter-box"></i>' . '</a></li>';
					}
					$instagram_url = get_the_author_meta( 'instagram_url' );
					if ( isset( $instagram_url ) && $instagram_url != '' ) {
						echo '<li class="instagram">' . '<a href="' . esc_url( $instagram_url ) . '">' . '<i class="mdi mdi-instagram"></i>' . '</a></li>';
					}
					$google_plus_url = get_the_author_meta( 'google_plus_url' );
					if ( isset( $google_plus_url ) && $google_plus_url != '' ) {
						echo '<li class="google-plus">' . '<a href="' . esc_url( $google_plus_url ) . '">' . '<i class="mdi mdi-google-plus-box"></i>' . '</a></li>';
					}
					$linkedin_url = get_the_author_meta( 'linkedin_url' );
					if ( isset( $linkedin_url ) && $linkedin_url != '' ) {
						echo '<li class="linkedin">' . '<a href="' . esc_url( $linkedin_url ) . '">' . '<i class="mdi mdi-linkedin"></i>' . '</a></li>';
					}
				?>
			</ul>
		</div>
	</div>

	<?php
}
endif;

if ( ! function_exists( 'mondo_related_posts' ) ) :
function mondo_related_posts( $author_disabled = false ) {

	$tags = wp_get_post_tags( get_the_ID() );

	$related_posts_class = '';
	$author_disabled ? $related_posts_class = 'author-disabled' : '';

	if ( $tags ) {
		$tag_ids = array();
		foreach ( $tags as $tag ) {
			$tag_ids[] = $tag->term_id;
		}

		$args = array(
			'tag__in' => $tag_ids,
      'post__not_in' => array( get_the_ID() ),
      'posts_per_page' => 3
		);

		$related_posts = new WP_Query( $args ); ?>

		<?php if ( $related_posts->have_posts() ) : ?>
			<section id="mondo-related-posts" class="<?php echo esc_attr( $related_posts_class ); ?>">
				<h3 id="related-posts-title"><?php _e( 'You might also like', 'mondo' ); ?></h3>

				<div class="row">
					<?php while ( $related_posts->have_posts() ) : $related_posts->the_post(); ?>
						<div class="col-md-4">

							<article class="related-post">
								<?php if ( has_post_thumbnail() ) : ?>
									<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">
										<div class="entry-media waves-effect waves-light waves-block">
											<?php the_post_thumbnail( 'rect_600', array( 'class' => 'opacity-element' ) ); ?>
										</div>
									</a>
								<?php endif; ?>
								<header class="entry-header">
									<?php the_title( sprintf( '<h4 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
									<div class="entry-meta">
										<?php mondo_posted_on( true ); ?>
									</div>
								</header>
							</article>

						</div>
					<?php endwhile; ?>
				</div>
			</section>
		<?php endif; ?>

		<?php wp_reset_postdata(); ?>

		<?php
	}
}
endif;

if ( ! function_exists( 'mondo_preloader' ) ) :
function mondo_preloader() {

	?>
	<div class="mondo-loading-screen">
		<div class="spinner">
			<div class="bounce1 spinner-element"></div>
		  <div class="bounce2 spinner-element"></div>
		  <div class="bounce3 spinner-element"></div>
		</div>
	</div>
	<?php
}
endif;

if ( ! function_exists( 'mondo_featured_posts' ) ) :
function mondo_featured_posts() {

	$args = array(
    'meta_key' => 'mondo_featured_post',
    'meta_value' => '1',
    'post_status' => 'publish',
    'ignore_sticky_posts' => true
  );
  $featured_posts = new WP_Query( $args ); ?>

  <?php if ( $featured_posts->have_posts() ) : ?>
  	<div id="mondo-featured-posts" class="owl-carousel">
  	<?php while ( $featured_posts->have_posts() ) : $featured_posts->the_post(); ?>

  		<?php
  			$bg_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'rect_1200' );
				$css = 'background-image: url(' . $bg_image[0] . ');';
  		?>

  		<article class="featured-post" style="<?php echo esc_attr( $css ); ?>">
	  		<?php mondo_love_link( false, false ); ?>

  			<!-- <div class="mondo-grid-mask"> -->
  				<?php if ( rwmb_meta( 'mondo_featured_post_label' ) != '' ) : ?>
	  				<span class="entry-label">
	  					<?php echo rwmb_meta( 'mondo_featured_post_label' ); ?>
	  				</span>
	  			<?php endif; ?>
					<div class="entry-content mondo-grid-content">
						<header class="entry-header">
							<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
						</header>
						<footer class="entry-footer mondo-grid-footer">
							<?php mondo_entry_footer_slim(); ?>
						</footer><!-- .entry-footer -->
					</div>
				<!-- </div> -->
  		</article>

	  <?php endwhile; ?>
	  </div>
  <?php endif;
}
endif;

if ( ! function_exists( 'mondo_search' ) ) :
function mondo_search() {

	?>

	<div id="mondo-search-fill"></div>
	<form role="search" method="get" class="search-form large" action="<?php echo home_url( '/' ); ?>">
		<input type="search" class="search-field" placeholder="<?php echo apply_filters( 'mondo_search_field_placeholder', __( 'Enter keyword...', 'mondo' ) ); ?>" value="<?php echo get_search_query() ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'mondo' ); ?>" autocomplete="off">
	</form>
	<a href="#" class="search-close"><i class="mdi mdi-close"></i></a>

	<?php
}
endif;

if ( ! function_exists( 'mondo_about_me' ) ) :
function mondo_about_me() {

	global $mondo_admin_data;

	ob_start(); ?>

	<div class="profile">
		<?php if ( isset( $mondo_admin_data['profile_image'] ) && mondo_redux_image_set( $mondo_admin_data['profile_image'] ) ) : ?>
			<img src="<?php echo esc_url( $mondo_admin_data['profile_image']['url'] ); ?>" class="profile-image img-circle" alt="<?php echo esc_attr( $mondo_admin_data['profile_name'] ); ?>">
			<div class="profile-name">
				<?php
					if ( isset( $mondo_admin_data['profile_name'] ) && mondo_redux_text_set( $mondo_admin_data['profile_name'] ) ) {
						echo esc_html( $mondo_admin_data['profile_name'] );
					}
				?>
			</div>
		<?php endif; ?>
	</div>

	<?php if ( isset( $mondo_admin_data['about_me_text'] ) && mondo_redux_text_set( $mondo_admin_data['about_me_text'] ) ) : ?>
		<div class="about-me">
			<?php echo wp_kses( $mondo_admin_data['about_me_text'], array(
				'a'      => array( 'href' => array() ),
				'span'   => array( 'style' => array() ),
				'i'      => array( 'class' => array(), 'style' => array() ),
				'em'     => array(),
				'strong' => array()
			) ); ?>
		</div>
	<?php endif; ?>

	<?php
	return ob_get_clean();
}
endif;

if ( ! function_exists( 'mondo_social_icons' ) ) :
function mondo_social_icons() {

	global $mondo_admin_data;

	$social_icons = array(
		'twitter_url' => 'twitter-box',
		'facebook_url' => 'facebook-box',
		'youtube_url' => 'youtube-play',
		'pinterest_url' => 'pinterest',
		'dribbble_url' => 'dribbble-box',
		'instagram_url' => 'instagram',
		'github_url' => 'github-box',
		'linkedin_url' => 'linkedin',
		'tumblr_url' => 'tumblr',
		'google_plus_url' => 'google-plus-box'
	);
?>

<div class="social-icons">
	<?php foreach ( $social_icons as $key => $value ) : ?>

		<?php if ( isset( $mondo_admin_data[ $key ] ) && $mondo_admin_data[ $key ] != '' ) : ?>
			<?php
				$social_icon_class = str_replace( '_url', '', $key );
				$social_icon_class = str_replace( '_', '-', $social_icon_class );
			?>
			<a href="<?php echo esc_url( $mondo_admin_data[ $key ] ); ?>" class="<?php echo esc_attr( $social_icon_class ); ?>"><i class="mdi mdi-<?php echo esc_attr( $value ); ?>"></i></a>
		<?php endif; ?>

	<?php endforeach; ?>
</div>

<?php
}
endif;

if ( ! function_exists( 'the_posts_navigation' ) ) :
/**
 * Display navigation to next/previous set of posts when applicable.
 *
 * @todo Remove this function when WordPress 4.3 is released.
 */
function the_posts_navigation() {
	// Don't print empty markup if there's only one page.
	if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
		return;
	}
	?>
	<nav class="navigation posts-navigation" role="navigation">
		<h2 class="screen-reader-text"><?php _e( 'Posts navigation', 'mondo' ); ?></h2>
		<div class="nav-links">

			<?php if ( get_next_posts_link() ) : ?>
			<div class="nav-previous"><?php next_posts_link( __( 'Older posts', 'mondo' ) ); ?></div>
			<?php endif; ?>

			<?php if ( get_previous_posts_link() ) : ?>
			<div class="nav-next"><?php previous_posts_link( __( 'Newer posts', 'mondo' ) ); ?></div>
			<?php endif; ?>

		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'the_masonry_posts_navigation' ) ) :
function the_masonry_posts_navigation() {
	?>
	<?php if ( get_next_posts_link() ) : ?>
		<nav class="navigation masonry-posts-navigation" role="navigation">
			<h2 class="screen-reader-text"><?php _e( 'Posts navigation', 'mondo' ); ?></h2>
			<a href="#" id="masonry-posts-load-more" class="waves-effect waves-button waves-float button-primary"><?php _e( 'Load More Posts', 'mondo' ); ?></a>
		</nav>
	<?php endif; ?>
	<?php
}
endif;

if ( ! function_exists( 'the_post_navigation' ) ) :
/**
 * Display navigation to next/previous post when applicable.
 *
 * @todo Remove this function when WordPress 4.3 is released.
 */
function the_post_navigation() {
	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous ) {
		return;
	}
	?>
	<nav class="navigation post-navigation" role="navigation">
		<h2 class="screen-reader-text"><?php _e( 'Post navigation', 'mondo' ); ?></h2>
		<div class="nav-links">
			<?php
				previous_post_link( '<div class="nav-previous">%link</div>', '%title' );
				next_post_link( '<div class="nav-next">%link</div>', '%title' );
			?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'mondo_comments_link' ) ) :
function mondo_comments_link( $icon = true, $bullet = false ) {

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		if ( $bullet ) {
			echo '<span class="separator"> &bull; </span>';
		}
		if ( $icon ) {
			echo '<span class="comments-link"><i class="mdi mdi-comment-outline"></i>';
			comments_popup_link( __( '0', 'mondo' ), __( '1', 'mondo' ), __( '%', 'mondo' ) );
			echo '</span>';
		} else {
			echo '<span class="comments-link"><i class="mdi mdi-comment visible-xs-inline-block"></i>';
			comments_popup_link(
				__( '0', 'mondo' ) . '<span class="hidden-xs"> ' . __( 'Comment', 'mondo' ) . '</span>',
				__( '1', 'mondo' ) . '<span class="hidden-xs"> ' . __( 'Comment', 'mondo' ) . '</span>',
				__( '%', 'mondo' ) . '<span class="hidden-xs"> ' . __( 'Comments', 'mondo' ) . '</span>'
			);
			echo '</span>';
		}
	}
}
endif;

if ( ! function_exists( 'mondo_categories_link' ) ) :
function mondo_categories_link( $icon = true, $sep = ', ', $bullet = false ) {

	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		if ( $bullet ) {
			echo '<span class="separator"> &bull; </span>';
		}
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( __( $sep, 'mondo' ) );
		if ( $categories_list && mondo_categorized_blog() ) {
			if ( $icon ) {
				printf( '<span class="cat-links"><i class="mdi mdi-checkbox-multiple-blank-outline"></i>' . __( '%1$s', 'mondo' ) . '</span>', $categories_list );
			} else {
				printf( '<span class="cat-links">' . __( '%1$s', 'mondo' ) . '</span>', $categories_list );	
			}
		}
	}
}
endif;

if ( ! function_exists( 'mondo_tags_link' ) ) :
function mondo_tags_link() {

	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		if ( is_single() ) {
			/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( '', __( ', ', 'mondo' ) );
			if ( $tags_list ) {
				printf( '<span class="tags-links"><i class="mdi mdi-tag-outline"></i>' . __( '%1$s', 'mondo' ) . '</span>', $tags_list );
			}
		}
	}
}
endif;

if ( ! function_exists( 'mondo_more_link' ) ) :
function mondo_more_link() {

	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		$twitter_url = 'https://twitter.com/share?url=' . get_the_permalink() . '&amp;text=' . get_the_title();
	  $facebook_url = 'http://www.facebook.com/sharer.php?u=' . get_the_permalink();
	  $google_plus_url = 'https://plus.google.com/share?url=' . get_the_permalink();
	  $pinterest_url = 'http://pinterest.com/pin/create/button/?url=' . get_the_permalink() . '&amp;description=' . get_the_title();
	  // $email_url = 'mailto:?subject=' . get_the_title() . '&amp;body=' . get_the_permalink();

		echo
			'<div class="more-links float-right"><i class="mdi mdi-dots-vertical"></i>' . 
				'<ul class="list">' .
					'<li class="facebook"><span class="waves-effect waves-block waves-classic"><a href="' . esc_url( $facebook_url ) . '" target="_blank"><i class="mdi mdi-facebook"></i></a></span></li>' .
					'<li class="twitter"><span class="waves-effect waves-block waves-classic"><a href="' . esc_url( $twitter_url ) . '" target="_blank"><i class="mdi mdi-twitter"></i></a></span></li>' .
					'<li class="google-plus"><span class="waves-effect waves-block waves-classic"><a href="' . esc_url( $google_plus_url ) . '" target="_blank"><i class="mdi mdi-google-plus"></i></a></span></li>' .
					'<li class="pinterest"><span class="waves-effect waves-block waves-classic"><a href="' . esc_url( $pinterest_url ) . '" target="_blank"><i class="mdi mdi-pinterest"></i></a></span></li>' .
					// '<li><span class="waves-effect waves-block waves-classic"><a href="' . esc_url( $email_url ) . '">' . __( 'Email', 'mondo' ) . '</a></span></li>' .
				'</ul>' .
			'</div>';
	}
}
endif;

if ( ! function_exists( 'mondo_edit_link' ) ) :
function mondo_edit_link() {

	edit_post_link( __( 'Edit', 'mondo' ), '<span class="edit-link">', '</span>' );
}
endif;

if ( ! function_exists( 'mondo_love_link' ) ) :
function mondo_love_link( $bullet = false, $container = true ) {

	if ( $bullet ) {
		echo '<span class="separator"> &bull; </span>';
	}

	$button_class = 'mondo-love-button';
	$container ? '' : $button_class .= ' waves-effect waves-circle';

	$love_button_text = '0';
	$love_count = get_post_meta( get_the_ID(), 'mondo_love', true );

	if ( $love_count != '' ) {
		$love_button_text = $love_count; 
	} ?>
	
	<?php if ( $container ) : ?>
	<span class="love-link">
	<?php endif; ?>
		<a href="#" class="<?php echo esc_attr( $button_class ); ?>" title="<?php _e( 'Click to love this post.', 'mondo' ); ?>" data-id="<?php echo esc_attr( get_the_ID() ); ?>">
			<i class="mdi mdi-heart-outline"></i>
			<span class="love-count"><?php echo esc_html( $love_button_text ); ?></span>
		</a>
	<?php if ( $container ) : ?>
	</span>
	<?php endif; ?>
	<?php
}
endif;

if ( ! function_exists( 'mondo_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function mondo_posted_on( $human_time = false ) {

	$entry_date = get_the_date();

	if ( $human_time ) {
		$entry_date = sprintf( __( '%s ago', 'mondo' ), human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) );
	}

	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( $entry_date )
	);

	$posted_on = sprintf(
		_x( '%s', 'post date', 'mondo' ),
		$time_string
	);

	$byline = sprintf(
		_x( 'by %s', 'post author', 'mondo' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	// echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>';
	echo '<span class="posted-on"><a href="' . get_permalink() . '" title="' . get_the_date( 'r' ) . '">' . $posted_on . '</a></span>';
}
endif;

if ( ! function_exists( 'mondo_entry_meta_standard' ) ) :
function mondo_entry_meta_standard() {

	if ( 'post' == get_post_type() ) {
		echo '<div class="entry-meta">';
		mondo_posted_on( true );
		mondo_comments_link( false, true );
		if ( mondo_categorized_blog() ) {
			mondo_categories_link( false, ', ', true );
		}
		mondo_love_link( true );
		echo '</div>';
	}
}
endif;

if ( ! function_exists( 'mondo_entry_footer_standard' ) ) :
function mondo_entry_footer_standard() {

	global $mondo_admin_data;

	$twitter_url = 'https://twitter.com/share?url=' . get_the_permalink() . '&amp;text=' . get_the_title();
  $facebook_url = 'http://www.facebook.com/sharer.php?u=' . get_the_permalink();
  $google_plus_url = 'https://plus.google.com/share?url=' . get_the_permalink();
  $pinterest_url = 'http://pinterest.com/pin/create/button/?url=' . get_the_permalink() . '&amp;description=' . get_the_title();
  // $email_url = 'mailto:?subject=' . get_the_title() . '&amp;body=' . get_the_permalink();

  $disable_sharer = mondo_compare_options( $mondo_admin_data['disable_sharer'], rwmb_meta( 'mondo_disable_sharer' ), 2 ); ?>
	
	<?php if ( ! is_single() ) : ?>
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="read-more waves-effect waves-button waves-float button-primary" rel="bookmark"><?php echo apply_filters( 'mondo_readmore_button_text', __( 'Read Article', 'mondo' ) ); ?></a>
	<?php endif; ?>

	<?php if ( $disable_sharer != '1' ) : ?>
		<div class="entry-share">
			<span class="label"><?php _e( 'Share:', 'mondo' ); ?></span>
			<ul class="links">
				<?php
					echo '<li class="facebook">' . '<a href="' . esc_url( $facebook_url ) . '">' . '<i class="mdi mdi-facebook-box"></i>' . '</a></li>';
					echo '<li class="twitter">' . '<a href="' . esc_url( $twitter_url ) . '">' . '<i class="mdi mdi-twitter-box"></i>' . '</a></li>';
					echo '<li class="google-plus">' . '<a href="' . esc_url( $google_plus_url ) . '">' . '<i class="mdi mdi-google-plus-box"></i>' . '</a></li>';
					echo '<li class="pinterest">' . '<a href="' . esc_url( $pinterest_url ) . '">' . '<i class="mdi mdi-pinterest"></i>' . '</a></li>';
					// echo '<li class="email">' . '<a href="' . esc_url( $email_url ) . '">' . '<i class="mdi mdi-email"></i>' . '</a></li>';
				?>
			</ul>
		</div>
	<?php endif; ?>

	<?php
}
endif;

if ( ! function_exists( 'mondo_entry_footer_slim' ) ) :
function mondo_entry_footer_slim() {

	mondo_categories_link( false );
}
endif;

if ( ! function_exists( 'mondo_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function mondo_entry_footer() {

	global $mondo_admin_data;

	$disable_sharer = mondo_compare_options( $mondo_admin_data['disable_sharer'], rwmb_meta( 'mondo_disable_sharer' ), 2 );

	mondo_categories_link();

	mondo_tags_link();

	if ( $disable_sharer != '1' ) {
		mondo_more_link();
	}

	mondo_comments_link();

	mondo_edit_link();
}
endif;

if ( ! function_exists( 'the_archive_title' ) ) :
/**
 * Shim for `the_archive_title()`.
 *
 * Display the archive title based on the queried object.
 *
 * @todo Remove this function when WordPress 4.3 is released.
 *
 * @param string $before Optional. Content to prepend to the title. Default empty.
 * @param string $after  Optional. Content to append to the title. Default empty.
 */
function the_archive_title( $before = '', $after = '' ) {
	if ( is_category() ) {
		$title = sprintf( __( 'Category: %s', 'mondo' ), single_cat_title( '', false ) );
	} elseif ( is_tag() ) {
		$title = sprintf( __( 'Tag: %s', 'mondo' ), single_tag_title( '', false ) );
	} elseif ( is_author() ) {
		$title = sprintf( __( 'Author: %s', 'mondo' ), '<span class="vcard">' . get_the_author() . '</span>' );
	} elseif ( is_year() ) {
		$title = sprintf( __( 'Year: %s', 'mondo' ), get_the_date( _x( 'Y', 'yearly archives date format', 'mondo' ) ) );
	} elseif ( is_month() ) {
		$title = sprintf( __( 'Month: %s', 'mondo' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'mondo' ) ) );
	} elseif ( is_day() ) {
		$title = sprintf( __( 'Day: %s', 'mondo' ), get_the_date( _x( 'F j, Y', 'daily archives date format', 'mondo' ) ) );
	} elseif ( is_tax( 'post_format' ) ) {
		if ( is_tax( 'post_format', 'post-format-aside' ) ) {
			$title = _x( 'Asides', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) {
			$title = _x( 'Galleries', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-image' ) ) {
			$title = _x( 'Images', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-video' ) ) {
			$title = _x( 'Videos', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-quote' ) ) {
			$title = _x( 'Quotes', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-link' ) ) {
			$title = _x( 'Links', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-status' ) ) {
			$title = _x( 'Statuses', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-audio' ) ) {
			$title = _x( 'Audio', 'post format archive title', 'mondo' );
		} elseif ( is_tax( 'post_format', 'post-format-chat' ) ) {
			$title = _x( 'Chats', 'post format archive title', 'mondo' );
		}
	} elseif ( is_post_type_archive() ) {
		$title = sprintf( __( 'Archives: %s', 'mondo' ), post_type_archive_title( '', false ) );
	} elseif ( is_tax() ) {
		$tax = get_taxonomy( get_queried_object()->taxonomy );
		/* translators: 1: Taxonomy singular name, 2: Current taxonomy term */
		$title = sprintf( __( '%1$s: %2$s', 'mondo' ), $tax->labels->singular_name, single_term_title( '', false ) );
	} else {
		$title = __( 'Archives', 'mondo' );
	}

	/**
	 * Filter the archive title.
	 *
	 * @param string $title Archive title to be displayed.
	 */
	$title = apply_filters( 'get_the_archive_title', $title );

	if ( ! empty( $title ) ) {
		echo $before . $title . $after;
	}
}
endif;

if ( ! function_exists( 'the_archive_description' ) ) :
/**
 * Shim for `the_archive_description()`.
 *
 * Display category, tag, or term description.
 *
 * @todo Remove this function when WordPress 4.3 is released.
 *
 * @param string $before Optional. Content to prepend to the description. Default empty.
 * @param string $after  Optional. Content to append to the description. Default empty.
 */
function the_archive_description( $before = '', $after = '' ) {
	$description = apply_filters( 'get_the_archive_description', term_description() );

	if ( ! empty( $description ) ) {
		/**
		 * Filter the archive description.
		 *
		 * @see term_description()
		 *
		 * @param string $description Archive description to be displayed.
		 */
		echo $before . $description . $after;
	}
}
endif;

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function mondo_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'mondo_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,

			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'mondo_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so mondo_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so mondo_categorized_blog should return false.
		return false;
	}
}

/**
 * Flush out the transients used in mondo_categorized_blog.
 */
function mondo_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'mondo_categories' );
}
add_action( 'edit_category', 'mondo_category_transient_flusher' );
add_action( 'save_post',     'mondo_category_transient_flusher' );

if ( ! function_exists( 'mondo_comment' ) ) :
/**
 * Customizes default comment output
 */
function mondo_comment( $comment, $args, $depth ) {

	$GLOBALS['comment'] = $comment;

	if ( 'pingback' == $comment->comment_type || 'trackback' == $comment->comment_type ) : ?>

	<li id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
		<div class="comment-body">
			<?php _e( 'Pingback:', 'mondo' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( __( 'Edit', 'mondo' ), '<span class="edit-link">', '</span>' ); ?>
		</div>

	<?php else : ?>

	<li id="comment-<?php comment_ID(); ?>" <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?>>
		<article id="div-comment-<?php comment_ID(); ?>" class="comment-body clearfix" itemscope itemtype="https://schema.org/Comment">
			<div class="comment-author-avatar vcard">
				<?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
			</div><!-- .comment-author -->

			<div class="comment-information">
				<div class="comment-author-name vcard" itemprop="author">
					<?php printf( __( '%s', 'mondo' ), sprintf( '<cite class="fn">%s</cite>', get_comment_author_link() ) ); ?>
				</div>

				<div class="comment-metadata">
					<time datetime="<?php comment_time( 'c' ); ?>" itemprop="datePublished">
						<?php printf( _x( '%1$s at %2$s', '1: date, 2: time', 'mondo' ), get_comment_date(), get_comment_time() ); ?>
					</time>
					<?php
						comment_reply_link( array_merge( $args, array(
							'add_below' => 'div-comment',
							'depth'     => $depth,
							'max_depth' => $args['max_depth'],
							'before'    => '<span class="reply">',
							'after'     => '</span>',
						) ) );
					?>
					<?php edit_comment_link( __( 'Edit', 'mondo' ), ' <span class="edit-link">', '</span>' ); ?>
				</div><!-- .comment-metadata -->

				<div class="comment-content" itemprop="comment">
					<?php comment_text(); ?>
				</div><!-- .comment-content -->

				<?php if ( '0' == $comment->comment_approved ) : ?>
				<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'mondo' ); ?></p>
				<?php endif; ?>
			</div>
		</article><!-- .comment-body -->

	<?php
	endif;
}
endif;
