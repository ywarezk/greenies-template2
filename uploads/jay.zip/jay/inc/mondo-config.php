<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux_Framework_sample_config' ) ) {

        class Redux_Framework_sample_config {

            public $args = array();
            public $sections = array();
            public $theme;
            public $ReduxFramework;

            public function __construct() {

                if ( ! class_exists( 'ReduxFramework' ) ) {
                    return;
                }

                // This is needed. Bah WordPress bugs.  ;)
                if ( true == Redux_Helpers::isTheme( __FILE__ ) ) {
                    $this->initSettings();
                } else {
                    add_action( 'plugins_loaded', array( $this, 'initSettings' ), 10 );
                }

            }

            public function initSettings() {

                // Just for demo purposes. Not needed per say.
                $this->theme = wp_get_theme();

                // Set the default arguments
                $this->setArguments();

                // Set a few help tabs so you can see how it's done
                // $this->setHelpTabs();

                // Create the sections and fields
                $this->setSections();

                if ( ! isset( $this->args['opt_name'] ) ) { // No errors please
                    return;
                }

                // If Redux is running as a plugin, this will remove the demo notice and links
                //add_action( 'redux/loaded', array( $this, 'remove_demo' ) );

                // Function to test the compiler hook and demo CSS output.
                // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
                add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 3);

                // Change the arguments after they've been declared, but before the panel is created
                //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );

                // Change the default value of a field after it's been set, but before it's been useds
                //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );

                // Dynamically add a section. Can be also used to modify sections/fields
                //add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

                $this->ReduxFramework = new ReduxFramework( $this->sections, $this->args );
            }

            /**
             * This is a test function that will let you see when the compiler hook occurs.
             * It only runs if a field    set with compiler=>true is changed.
             * */
            function compiler_action( $options, $css, $changed_values ) {

                if ( array_key_exists( 'instagram_username', $changed_values ) ) {
                    delete_transient( 'mondo_widget_instagram' );
                    delete_transient( 'mondo_media_feed_instagram' );
                    delete_transient( 'mondo_instagram_user_id' );
                } else if ( array_key_exists( 'flickr_user_id', $changed_values ) ) {
                    delete_transient( 'mondo_widget_flickr' );
                } else if ( array_key_exists( 'dribbble_username', $changed_values ) ) {
                    delete_transient( 'mondo_widget_dribbble' );
                    delete_transient( 'mondo_media_feed_dribbble' );
                } else if ( array_key_exists( 'instagram_client_id', $changed_values ) ) {
                    // echo json_encode( array(
                    //     'status' => 'lol',
                    //     'action' => 'reload'
                    // ) );

                    // die();
                }

                // echo '<h1>The compiler hook has run!</h1>';
                // echo "<pre>";
                // print_r( $changed_values ); // Values that have changed since the last save
                // echo "</pre>";
                //print_r($options); //Option values
                //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )

                /*
              // Demo of how to use the dynamic CSS and write your own static CSS file
              $filename = dirname(__FILE__) . '/style' . '.css';
              global $wp_filesystem;
              if( empty( $wp_filesystem ) ) {
                require_once( ABSPATH .'/wp-admin/includes/file.php' );
              WP_Filesystem();
              }

              if( $wp_filesystem ) {
                $wp_filesystem->put_contents(
                    $filename,
                    $css,
                    FS_CHMOD_FILE // predefined mode settings for WP files
                );
              }
             */
            }

            /**
             * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
             * Simply include this function in the child themes functions.php file.
             * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
             * so you must use get_template_directory_uri() if you want to use any of the built in icons
             * */
            function dynamic_section( $sections ) {
                //$sections = array();
                $sections[] = array(
                    'title'  => __( 'Section via hook', 'redux-framework-demo' ),
                    'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'redux-framework-demo' ),
                    'icon'   => 'el el-paper-clip',
                    // Leave this as a blank section, no options just some intro text set above.
                    'fields' => array()
                );

                return $sections;
            }

            /**
             * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
             * */
            function change_arguments( $args ) {
                //$args['dev_mode'] = true;

                return $args;
            }

            /**
             * Filter hook for filtering the default value of any given field. Very useful in development mode.
             * */
            function change_defaults( $defaults ) {
                $defaults['str_replace'] = 'Testing filter hook!';

                return $defaults;
            }

            // Remove the demo link and the notice of integrated demo from the redux-framework plugin
            function remove_demo() {

                // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
                if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                    remove_filter( 'plugin_row_meta', array(
                        ReduxFrameworkPlugin::instance(),
                        'plugin_metalinks'
                    ), null, 2 );

                    // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                    remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
                }
            }

            public function setSections() {

                /**
                 * Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
                 * */
                // Background Patterns Reader
                $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
                $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
                $sample_patterns      = array();

                if ( is_dir( $sample_patterns_path ) ) :

                    if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) :
                        $sample_patterns = array();

                        while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                            if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                                $name              = explode( '.', $sample_patterns_file );
                                $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                                $sample_patterns[] = array(
                                    'alt' => $name,
                                    'img' => $sample_patterns_url . $sample_patterns_file
                                );
                            }
                        }
                    endif;
                endif;

                ob_start();

                $ct          = wp_get_theme();
                $this->theme = $ct;
                $item_name   = $this->theme->get( 'Name' );
                $tags        = $this->theme->Tags;
                $screenshot  = $this->theme->get_screenshot();
                $class       = $screenshot ? 'has-screenshot' : '';

                $customize_title = sprintf( __( 'Customize &#8220;%s&#8221;', 'redux-framework-demo' ), $this->theme->display( 'Name' ) );

                ?>
                <div id="current-theme" class="<?php echo esc_attr( $class ); ?>">
                    <?php if ( $screenshot ) : ?>
                        <?php if ( current_user_can( 'edit_theme_options' ) ) : ?>
                            <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize"
                               title="<?php echo esc_attr( $customize_title ); ?>">
                                <img src="<?php echo esc_url( $screenshot ); ?>"
                                     alt="<?php esc_attr_e( 'Current theme preview', 'redux-framework-demo' ); ?>"/>
                            </a>
                        <?php endif; ?>
                        <img class="hide-if-customize" src="<?php echo esc_url( $screenshot ); ?>"
                             alt="<?php esc_attr_e( 'Current theme preview', 'redux-framework-demo' ); ?>"/>
                    <?php endif; ?>

                    <h4><?php echo esc_html( $this->theme->display( 'Name' ) ); ?></h4>

                    <div>
                        <ul class="theme-info">
                            <li><?php printf( __( 'By %s', 'redux-framework-demo' ), $this->theme->display( 'Author' ) ); ?></li>
                            <li><?php printf( __( 'Version %s', 'redux-framework-demo' ), $this->theme->display( 'Version' ) ); ?></li>
                            <li><?php echo '<strong>' . __( 'Tags', 'redux-framework-demo' ) . ':</strong> '; ?><?php printf( $this->theme->display( 'Tags' ) ); ?></li>
                        </ul>
                        <p class="theme-description"><?php echo esc_html( $this->theme->display( 'Description' ) ); ?></p>
                        <?php
                            if ( $this->theme->parent() ) {
                                printf( ' <p class="howto">' . __( 'This <a href="%1$s">child theme</a> requires its parent theme, %2$s.', 'redux-framework-demo' ) . '</p>', __( 'http://codex.wordpress.org/Child_Themes', 'redux-framework-demo' ), $this->theme->parent()->display( 'Name' ) );
                            }
                        ?>

                    </div>
                </div>

                <?php
                $item_info = ob_get_contents();

                ob_end_clean();

                $sampleHTML = '';
                if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
                    Redux_Functions::initWpFilesystem();

                    global $wp_filesystem;

                    $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
                }

                // ACTUAL DECLARATION OF SECTIONS

                $this->sections[] = array(
                    'title'  => __( 'General Settings', 'mondo' ),
                    'icon'   => 'el el-home',
                    'fields' => array(
                        array(
                            'id'       => 'main_layout',
                            'type'     => 'select',
                            'title'    => __( 'Main Layout', 'mondo' ),
                            'options'  => array(
                                'right_sidebar' => 'Right Sidebar',
                                'left_sidebar' => 'Left Sidebar',
                                'full_width' => 'Full Width',
                                'masonry' => 'Masonry',
                                'masonry_right_sidebar' => 'Masonry Right Sidebar',
                                'masonry_left_sidebar' => 'Masonry Left Sidebar',
                                'grid' => 'Grid',
                                'parallax' => 'Parallax'
                            ),
                            'default'  => 'right_sidebar'
                        ),
                        array(
                            'id'       => 'disable_preloader',
                            'type'     => 'checkbox',
                            'title'    => __('Disable Preloader', 'mondo'), 
                            'subtitle' => __('Check to disable the preloader which appears on page load.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'disable_scrollbar',
                            'type'     => 'checkbox',
                            'title'    => __('Disable Scrollbar', 'mondo'), 
                            'subtitle' => __('Check to disable the scrollbar which appears on top of page.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'enable_search',
                            'type'     => 'checkbox',
                            'title'    => __('Enable Search', 'mondo'), 
                            'subtitle' => __('Check to enable fullscreen search feature.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'enable_sidemenu',
                            'type'     => 'checkbox',
                            'title'    => __('Enable Side Menu', 'mondo'), 
                            'subtitle' => __('Check to enable side menu.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'enable_media_feed',
                            'type'     => 'checkbox',
                            'title'    => __('Enable Media Feed', 'mondo'), 
                            'subtitle' => __('Check to enable media feed above the footer.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'media_feed_type',
                            'type'     => 'select',
                            'title'    => __( 'Media Feed Type', 'mondo' ),
                            'options'  => array(
                                'instagram' => 'Instagram',
                                'dribbble' => 'Dribbble'
                            ),
                            'default'  => 'instagram'
                        ),
                        array(
                            'id'      => 'copyright_text',
                            'type'    => 'editor',
                            'title'   => __('Copyright', 'mondo'), 
                            'default' => 'Proudly powered by WordPress.',
                        ),
                    )
                );

                $this->sections[] = array(
                    'title'  => __('Blog Settings', 'mondo'),
                    'icon'   => 'el-icon-edit',
                    'fields' => array(
                        array(
                            'id'       => 'post_content',
                            'type'     => 'select',
                            'title'    => __( 'Post Content', 'mondo' ),
                            'options'  => array(
                                'content' => 'Content',
                                'excerpt' => 'Excerpt'
                            ),
                            'default'  => 'content'
                        ),
                        array(
                            'id'       => 'excerpt_length',
                            'type'     => 'text',
                            'title'    => __('Excerpt Length', 'mondo'),
                            'default'  => '55'
                        ),
                        array(
                            'id'       => 'enable_feature',
                            'type'     => 'checkbox',
                            'title'    => __('Enable Featured Posts', 'mondo'), 
                            'subtitle' => __('Check to enable featured posts on home page.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'enable_feature_arrow',
                            'type'     => 'checkbox',
                            'title'    => __('Enable Featured Posts Arrow', 'mondo'), 
                            'subtitle' => __('Check to show navigation arrows on featured posts.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'feature_column',
                            'type'     => 'select',
                            'title'    => __( 'Featured Posts Column', 'mondo' ),
                            'options'  => array(
                                '1' => '1',
                                '2' => '2',
                                '3' => '3',
                                '4' => '4',
                                '5' => '5',
                            ),
                            'default'  => '3'
                        ),
                        array(
                            'id'       => 'enable_author',
                            'type'     => 'checkbox',
                            'title'    => __('Enable Author Section', 'mondo'), 
                            'subtitle' => __('Check to enable author section on single post. Customize author settings from Users > Your Profile.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'enable_relate',
                            'type'     => 'checkbox',
                            'title'    => __('Enable Related Posts', 'mondo'), 
                            'subtitle' => __('Check to enable related posts on single post.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'disable_sharer',
                            'type'     => 'checkbox',
                            'title'    => __('Disable Sharer', 'mondo'), 
                            'subtitle' => __('Check to disable sharer on posts.', 'mondo'),
                            'default'  => '0'
                        ),
                        // array(
                        //     'id'      => 'blog_filter',
                        //     'type'    => 'sorter',
                        //     'title'   => __('Blog Filter', 'mondo'),
                        //     'subtitle' => __('Please note that blog filter only works on masonry layout.', 'mondo'),
                        //     'options' => array(
                        //         'enabled'  => array(
                        //             '*' => 'All',
                        //             'standard' => 'Standard',
                        //             'image' => 'Image',
                        //             'audio' => 'Audio',
                        //             'video' => 'Video',
                        //             'gallery' => 'Gallery'
                        //         ),
                        //         'disabled' => array(
                        //             'quote' => 'Quote',
                        //             'link' => 'Link',
                        //             // 'status' => 'Status',
                        //             // 'chat' => 'Chat',
                        //             // 'aside' => 'Aside'
                        //         )
                        //     ),
                        // ),
                        array(
                            'id'       => 'posts_navigation',
                            'type'     => 'select',
                            'title'    => __( 'Posts Navigation', 'mondo' ),
                            'options'  => array(
                                'link' => 'Navigation Links',
                                'pagination' => 'Numbered Pagination',
                            ),
                            'default'  => 'link'
                        ),
                        array(
                            'id'       => 'section-start',
                            'type'     => 'section',
                            'title'    => __('Titlebar Options', 'mondo'),
                            'indent'   => true 
                        ),
                        array(
                            'id'       => 'blog_titlebar_style',
                            'type'     => 'select',
                            'title'    => __( 'Titlebar Style', 'mondo' ),
                            'options'  => array(
                                'no' => 'No Titlebar',
                                'thin' => 'Thin Titlebar',
                                'wide' => 'Wide Titlebar',
                                'full' => 'Full Titlebar'
                            ),
                            'default'  => 'no'
                        ),
                        array(
                            'id'       => 'blog_titlebar_title',
                            'type'     => 'text',
                            'title'    => __('Titlebar Title', 'mondo'),
                        ),
                        array(
                            'id'       => 'blog_titlebar_subtitle',
                            'type'     => 'text',
                            'title'    => __('Titlebar Subtitle', 'mondo'),
                        ),
                        array(
                            'id'       => 'blog_titlebar_image',
                            'type'     => 'media', 
                            'url'      => true,
                            'title'    => __('Titlebar Background Image', 'mondo'),
                        ),
                        array(
                            'id'       => 'blog_titlebar_blur',
                            'type'     => 'media', 
                            'url'      => true,
                            'title'    => __('Titlebar Blurred Background Image', 'mondo'),
                        ),
                        array(
                            'id'     => 'section-end',
                            'type'   => 'section',
                            'indent' => false,
                        ),
                    )
                );

                $this->sections[] = array(
                    'title'  => __('Styling', 'mondo'),
                    'icon'   => 'el-icon-magic',
                    'fields' => array(
                        array(
                            'id'       => 'main_navigation_style',
                            'type'     => 'select',
                            'title'    => __( 'Main Navigation Style', 'mondo' ),
                            'options'  => array(
                                'default' => 'Default',
                                'transparent' => 'Transparent',
                                'sticky' => 'Sticky',
                                'sticky-transparent' => 'Sticky + Transparent',
                            ),
                            'default'  => 'default'
                        ),
                        array(
                            'id'          => 'primary_color',
                            'type'        => 'color',
                            'title'       => __('Primary Color', 'mondo'), 
                            'validate'    => 'color',
                            'transparent' => false,
                        ),
                        array(
                            'id'          => 'accent_color',
                            'type'        => 'color',
                            'title'       => __('Accent Color', 'mondo'), 
                            'validate'    => 'color',
                            'transparent' => false,
                        ),
                        array(
                            'id'          => 'title_font',
                            'type'        => 'typography', 
                            'title'       => __('Title Font', 'mondo'),
                            'google'      => true, 
                            'font-backup' => false,
                            'font-weight' => false,
                            'font-style'  => false,
                            'text-align'  => false,
                            'font-size'   => false,
                            'line-height' => false,
                            'color'       => false,
                            'output'      => array(
                                '.main-navigation .nav-list > .menu-item > span > a',
                                'h1',
                                'h2',
                                'h3',
                                'h4',
                                'h5',
                                'h6',
                                '.widget ul li a',
                                '.pushy .profile-name',
                                '.widget_mondo_about_widget .profile-name',
                                '.main-navigation .text-logo'
                            ),
                            'units'       =>'px',
                        ),
                        array(
                            'id'          => 'body_font',
                            'type'        => 'typography', 
                            'title'       => __('Body Font', 'mondo'),
                            'google'      => true, 
                            'font-backup' => false,
                            'font-weight' => false,
                            'font-style'  => false,
                            'text-align'  => false,
                            'font-size'   => false,
                            'line-height' => false,
                            'color'       => false,
                            'output'      => array('body', '#mondo-titlebar .page-subtitle'),
                            'units'       =>'px',
                        ),
                        array(
                            'id'       => 'header_logo',
                            'type'     => 'media', 
                            'url'      => true,
                            'title'    => __('Header Logo', 'mondo'),
                        ),
                        array(
                            'id'       => 'header_logo_contrast',
                            'type'     => 'media', 
                            'url'      => true,
                            'title'    => __('Header Logo (contrast)', 'mondo'),
                            'subtitle' => __('It is used when sticky+transparent navigation hides your logo on white background', 'mondo'),
                        ),
                        array(
                            'id'       => 'custom_css',
                            'type'     => 'ace_editor',
                            'title'    => __('Custom CSS', 'mondo'),
                            'mode'     => 'css',
                            'theme'    => 'monokai',
                        ),
                    )
                );

                $this->sections[] = array(
                    'title'  => __('About Me', 'mondo'),
                    'icon'   => 'el-icon-user',
                    'fields' => array(
                        array(
                            'id'       => 'enable_about',
                            'type'     => 'checkbox',
                            'title'    => __('Enable About Me', 'mondo'), 
                            'subtitle' => __('Check to enable "About Me" section on the side menu. Be sure to enable the side menu as well.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'    => 'about_me_bg_image',
                            'type'  => 'media', 
                            'url'   => true,
                            'title' => __('Profile Backgroud Image', 'mondo'),
                        ),
                        array(
                            'id'      => 'profile_name',
                            'type'    => 'text',
                            'title'   => __('Profile Name', 'mondo'),
                            'default' => 'MondoTheme',
                        ),
                        array(
                            'id'    => 'profile_image',
                            'type'  => 'media', 
                            'url'   => true,
                            'title' => __('Profile Image', 'mondo'),
                        ),
                        array(
                            'id'      => 'about_me_text',
                            'type'    => 'editor',
                            'title'   => __('About Me', 'mondo'), 
                            'default' => 'Write something nice about yourself.',
                        ),
                    )
                );

                $this->sections[] = array(
                    'title'  => __('Social Media', 'mondo'),
                    'icon'   => 'el-icon-group',
                    'fields' => array(
                        array(
                            'id'       => 'section-start',
                            'type'     => 'section',
                            'title'    => __('Instagram Options', 'mondo'),
                            'indent'   => true 
                        ),
                        array(
                            'id'       => 'instagram_client_id',
                            'type'     => 'text',
                            'title'    => __('Instagram Client ID', 'mondo'),
                            'default'  => 'Fill it before signing in.',
                            'compiler' => true,
                        ),
                        array(
                            'id'       => 'instagram_client_secret',
                            'type'     => 'text',
                            'title'    => __('Instagram Client Secret', 'mondo'),
                            'default'  => 'Fill it before signing in.',
                            'compiler' => true,
                        ),
                        array(
                            'id'       => 'instagram_username',
                            'type'     => 'text',
                            'title'    => __('Instagram Username', 'mondo'),
                            'compiler' => true,
                        ),
                        getInstagramAuthenticationField(),
                        array(
                            'id'     => 'section-end',
                            'type'   => 'section',
                            'indent' => false,
                        ),
                        array(
                            'id'       => 'section-start',
                            'type'     => 'section',
                            'title'    => __('Flickr Options', 'mondo'),
                            'indent'   => true 
                        ),
                        array(
                            'id'       => 'flickr_api_key',
                            'type'     => 'text',
                            'title'    => __('Flickr API Key', 'mondo'),
                        ),
                        array(
                            'id'       => 'flickr_user_id',
                            'type'     => 'text',
                            'title'    => __('Flickr User ID', 'mondo'),
                            'subtitle' => sprintf( __( 'Click %shere%s to get Flickr User ID.', 'mondo' ), '<a href="http://' . 'idgettr.com/" target="_blank">', '</a>' ),
                            'compiler' => true,
                        ),
                        array(
                            'id'     => 'section-end',
                            'type'   => 'section',
                            'indent' => false,
                        ),
                        array(
                            'id'       => 'section-start',
                            'type'     => 'section',
                            'title'    => __('Dribbble Options', 'mondo'),
                            'indent'   => true 
                        ),
                        array(
                            'id'       => 'dribbble_access_token',
                            'type'     => 'text',
                            'title'    => __('Dribbble Access Token', 'mondo'),
                        ),
                        array(
                            'id'       => 'dribbble_username',
                            'type'     => 'text',
                            'title'    => __('Dribbble Username', 'mondo'),
                            'compiler' => true,
                        ),
                        array(
                            'id'     => 'section-end',
                            'type'   => 'section',
                            'indent' => false,
                        ),
                        array(
                            'id'       => 'section-start',
                            'type'     => 'section',
                            'title'    => __('Social Links Options', 'mondo'),
                            'indent'   => true 
                        ),
                        array(
                            'id'       => 'twitter_url',
                            'type'     => 'text',
                            'title'    => __('Twitter URL', 'mondo'),
                            'default'  => 'http://twitter.com',
                        ),
                        array(
                            'id'       => 'facebook_url',
                            'type'     => 'text',
                            'title'    => __('Facebook URL', 'mondo'),
                            'default'  => 'http://facebook.com',
                        ),
                        array(
                            'id'       => 'youtube_url',
                            'type'     => 'text',
                            'title'    => __('YouTube URL', 'mondo'),
                            'default'  => 'http://youtube.com',
                        ),
                        array(
                            'id'       => 'pinterest_url',
                            'type'     => 'text',
                            'title'    => __('Pinterest URL', 'mondo'),
                            'default'  => 'http://pinterest.com',
                        ),
                        array(
                            'id'       => 'dribbble_url',
                            'type'     => 'text',
                            'title'    => __('Dribbble URL', 'mondo'),
                        ),
                        array(
                            'id'       => 'instagram_url',
                            'type'     => 'text',
                            'title'    => __('Instagram URL', 'mondo'),
                        ),
                        array(
                            'id'       => 'github_url',
                            'type'     => 'text',
                            'title'    => __('GitHub URL', 'mondo'),
                        ),
                        array(
                            'id'       => 'linkedin_url',
                            'type'     => 'text',
                            'title'    => __('LinkedIn URL', 'mondo'),
                        ),
                        array(
                            'id'       => 'tumblr_url',
                            'type'     => 'text',
                            'title'    => __('Tumblr URL', 'mondo'),
                        ),
                        array(
                            'id'       => 'google_plus_url',
                            'type'     => 'text',
                            'title'    => __('Google+ URL', 'mondo'),
                        ),
                        array(
                            'id'     => 'section-end',
                            'type'   => 'section',
                            'indent' => false,
                        ),
                    )
                );

                $this->sections[] = array(
                    'title'  => __('Shop', 'mondo'),
                    'icon'   => 'el-icon-shopping-cart',
                    'fields' => array(
                        array(
                            'id'       => 'shop_layout',
                            'type'     => 'select',
                            'title'    => __( 'Shop Layout', 'mondo' ),
                            'options'  => array(
                                'left_sidebar' => 'Left Sidebar',
                                'right_sidebar' => 'Right Sidebar',
                                'full_width' => 'Full Width',
                            ),
                            'default'  => 'left_sidebar'
                        ),
                        array(
                            'id'       => 'shop_disable_cart',
                            'type'     => 'checkbox',
                            'title'    => __('Disable Cart', 'mondo'), 
                            'subtitle' => __('Check to disable a cart item on the navigation menu.', 'mondo'),
                            'default'  => '0'
                        ),
                        array(
                            'id'       => 'section-start',
                            'type'     => 'section',
                            'title'    => __('Titlebar Options', 'mondo'),
                            'indent'   => true 
                        ),
                        array(
                            'id'       => 'shop_titlebar_style',
                            'type'     => 'select',
                            'title'    => __( 'Titlebar Style', 'mondo' ),
                            'options'  => array(
                                'no' => 'No Titlebar',
                                'thin' => 'Thin Titlebar',
                                'wide' => 'Wide Titlebar',
                                'full' => 'Full Titlebar'
                            ),
                            'default'  => 'no'
                        ),
                        array(
                            'id'       => 'shop_titlebar_title',
                            'type'     => 'text',
                            'title'    => __('Titlebar Title', 'mondo'),
                        ),
                        array(
                            'id'       => 'shop_titlebar_subtitle',
                            'type'     => 'text',
                            'title'    => __('Titlebar Subtitle', 'mondo'),
                        ),
                        array(
                            'id'       => 'shop_titlebar_image',
                            'type'     => 'media', 
                            'url'      => true,
                            'title'    => __('Titlebar Background Image', 'mondo'),
                        ),
                        array(
                            'id'       => 'shop_titlebar_blur',
                            'type'     => 'media', 
                            'url'      => true,
                            'title'    => __('Titlebar Blurred Background Image', 'mondo'),
                        ),
                        array(
                            'id'     => 'section-end',
                            'type'   => 'section',
                            'indent' => false,
                        ),
                    )
                );

                $this->sections[] = array(
                    'title'  => __('Footer', 'mondo'),
                    'icon'   => 'el-icon-hand-down',
                    'fields' => array(
                        array(
                            'id'       => 'footer_style',
                            'type'     => 'select',
                            'title'    => __('Style', 'mondo'), 
                            'options'  => array('slim' => 'Slim', 'widgetized' => 'Widgetized'),
                            'default'  => 'slim'
                        ),
                        array(
                            'id'       => 'footer_column',
                            'type'     => 'select',
                            'title'    => __('Column', 'mondo'), 
                            'subtitle' => __('Note: It only works if you chose widgetized footer style.', 'mondo'),
                            'options'  => array('2' => '2', '3' => '3', '4' => '4'),
                            'default'  => '4'
                        ),
                    )
                );

                // if ( file_exists( dirname( __FILE__ ) . '/../README.md' ) ) {
                //     $this->sections['theme_docs'] = array(
                //         'icon'   => 'el el-list-alt',
                //         'title'  => __( 'Documentation', 'mondo' ),
                //         'fields' => array(
                //             array(
                //                 'id'       => 'mondo_documentation',
                //                 'type'     => 'raw',
                //                 'markdown' => true,
                //                 'content'  => file_get_contents( 'http://static.mondotheme.com/jay/documentation/README-JAY.md' ),
                //             ),
                //         ),
                //     );
                // }

                $this->sections[] = array(
                    'title'  => __( 'Import / Export', 'redux-framework-demo' ),
                    'desc'   => __( 'Import and Export your Redux Framework settings from file, text or URL.', 'redux-framework-demo' ),
                    'icon'   => 'el el-refresh',
                    'fields' => array(
                        array(
                            'id'         => 'opt-import-export',
                            'type'       => 'import_export',
                            'title'      => 'Import Export',
                            'subtitle'   => 'Save and restore your Redux options',
                            'full_width' => false,
                        ),
                    ),
                );

                if ( file_exists( trailingslashit( dirname( __FILE__ ) ) . 'README.html' ) ) {
                    $tabs['docs'] = array(
                        'icon'    => 'el el-book',
                        'title'   => __( 'Documentation', 'redux-framework-demo' ),
                        'content' => nl2br( file_get_contents( trailingslashit( dirname( __FILE__ ) ) . 'README.html' ) )
                    );
                }
            }

            public function setHelpTabs() {

                // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
                $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-1',
                    'title'   => __( 'Theme Information 1', 'redux-framework-demo' ),
                    'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
                );

                $this->args['help_tabs'][] = array(
                    'id'      => 'redux-help-tab-2',
                    'title'   => __( 'Theme Information 2', 'redux-framework-demo' ),
                    'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
                );

                // Set the help sidebar
                $this->args['help_sidebar'] = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'redux-framework-demo' );
            }

            /**
             * All the possible arguments for Redux.
             * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
             * */
            public function setArguments() {

                $theme = wp_get_theme(); // For use with some settings. Not necessary.

                $this->args = array(
                    // TYPICAL -> Change these values as you need/desire
                    'opt_name'             => 'mondo_admin_options',
                    // This is where your data is stored in the database and also becomes your global variable name.
                    'display_name'         => $theme->get( 'Name' ),
                    // Name that appears at the top of your panel
                    'display_version'      => $theme->get( 'Version' ),
                    // Version that appears at the top of your panel
                    'menu_type'            => 'menu',
                    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                    'allow_sub_menu'       => true,
                    // Show the sections below the admin menu item or not
                    'menu_title'           => __( 'Jay Options', 'redux-framework-demo' ),
                    'page_title'           => __( 'Jay Options', 'redux-framework-demo' ),
                    // You will need to generate a Google API key to use this feature.
                    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                    'google_api_key'       => '',
                    // Set it you want google fonts to update weekly. A google_api_key value is required.
                    'google_update_weekly' => false,
                    // Must be defined to add google fonts to the typography module
                    'async_typography'     => true,
                    // Use a asynchronous font on the front end or font string
                    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
                    'admin_bar'            => true,
                    // Show the panel pages on the admin bar
                    'admin_bar_icon'     => 'dashicons-portfolio',
                    // Choose an icon for the admin bar menu
                    'admin_bar_priority' => 50,
                    // Choose an priority for the admin bar menu
                    'global_variable'      => 'mondo_admin_data',
                    // Set a different name for your global variable other than the opt_name
                    'dev_mode'             => false,
                    // Show the time the page took to load, etc
                    'update_notice'        => true,
                    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
                    'customizer'           => true,
                    // Enable basic customizer support
                    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
                    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

                    // OPTIONAL -> Give you extra features
                    'page_priority'        => null,
                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                    'page_parent'          => 'themes.php',
                    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                    'page_permissions'     => 'manage_options',
                    // Permissions needed to access the options panel.
                    'menu_icon'            => '',
                    // Specify a custom URL to an icon
                    'last_tab'             => '',
                    // Force your panel to always open to a specific tab (by id)
                    'page_icon'            => 'icon-themes',
                    // Icon displayed in the admin panel next to your menu_title
                    'page_slug'            => '_options',
                    // Page slug used to denote the panel
                    'save_defaults'        => true,
                    // On load save the defaults to DB before user clicks save or not
                    'default_show'         => false,
                    // If true, shows the default value next to each field that is not the default value.
                    'default_mark'         => '',
                    // What to print by the field's title if the value shown is default. Suggested: *
                    'show_import_export'   => true,
                    // Shows the Import/Export panel when not used as a field.

                    // CAREFUL -> These options are for advanced use only
                    'transient_time'       => 60 * MINUTE_IN_SECONDS,
                    'output'               => true,
                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                    'output_tag'           => true,
                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

                    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                    'database'             => '',
                    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                    'system_info'          => false,
                    // REMOVE

                    // HINTS
                    'hints'                => array(
                        'icon'          => 'el el-question-sign',
                        'icon_position' => 'right',
                        'icon_color'    => 'lightgray',
                        'icon_size'     => 'normal',
                        'tip_style'     => array(
                            'color'   => 'light',
                            'shadow'  => true,
                            'rounded' => false,
                            'style'   => '',
                        ),
                        'tip_position'  => array(
                            'my' => 'top left',
                            'at' => 'bottom right',
                        ),
                        'tip_effect'    => array(
                            'show' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'mouseover',
                            ),
                            'hide' => array(
                                'effect'   => 'slide',
                                'duration' => '500',
                                'event'    => 'click mouseleave',
                            ),
                        ),
                    )
                );

                // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
                $this->args['admin_bar_links'][] = array(
                    'id'    => 'mondo-support',
                    'href'   => 'http://mondotheme.ticksy.com/',
                    'title' => __( 'Support', 'mondo' ),
                );

                $this->args['admin_bar_links'][] = array(
                    'id'    => 'mondo-website',
                    'href'   => 'http://mondotheme.com/',
                    'title' => __( 'Website', 'mondo' ),
                );

                $this->args['admin_bar_links'][] = array(
                    'id'    => 'mondo-profile',
                    'href'   => 'http://themeforest.net/user/mondotheme',
                    'title' => __( 'ThemeForest Profile', 'mondo' ),
                );

                $this->args['admin_bar_links'][] = array(
                    'id'    => 'mondo-facebook',
                    'href'   => 'https://www.facebook.com/mondotheme',
                    'title' => __( 'Facebook', 'mondo' ),
                );

                $this->args['admin_bar_links'][] = array(
                    'id'    => 'mondo-twitter',
                    'href'   => 'https://twitter.com/mondotheme',
                    'title' => __( 'Twitter', 'mondo' ),
                );

                $this->args['admin_bar_links'][] = array(
                    'id'    => 'mondo-instagram',
                    'href'   => 'https://instagram.com/mondotheme/',
                    'title' => __( 'Instagram', 'mondo' ),
                );

                // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
                // $this->args['share_icons'][] = array(
                //     'url'   => 'https://github.com/ReduxFramework/ReduxFramework',
                //     'title' => 'Visit us on GitHub',
                //     'icon'  => 'el el-github'
                //     //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
                // );
                $this->args['share_icons'][] = array(
                    'url'   => 'https://www.facebook.com/mondotheme',
                    'title' => 'Like us on Facebook',
                    'icon'  => 'el el-facebook'
                );
                $this->args['share_icons'][] = array(
                    'url'   => 'https://twitter.com/mondotheme',
                    'title' => 'Follow us on Twitter',
                    'icon'  => 'el el-twitter'
                );
                // $this->args['share_icons'][] = array(
                //     'url'   => 'http://www.linkedin.com/company/redux-framework',
                //     'title' => 'Find us on LinkedIn',
                //     'icon'  => 'el el-linkedin'
                // );

                // Panel Intro text -> before the form
                // if ( ! isset( $this->args['global_variable'] ) || $this->args['global_variable'] !== false ) {
                //     if ( ! empty( $this->args['global_variable'] ) ) {
                //         $v = $this->args['global_variable'];
                //     } else {
                //         $v = str_replace( '-', '_', $this->args['opt_name'] );
                //     }
                //     $this->args['intro_text'] = sprintf( __( '<p>Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p>', 'redux-framework-demo' ), $v );
                // } else {
                //     $this->args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'redux-framework-demo' );
                // }

                // Add content after the form.
                // $this->args['footer_text'] = __( '<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'redux-framework-demo' );
            }

            public function validate_callback_function( $field, $value, $existing_value ) {
                $error = true;
                $value = 'just testing';

                /*
              do your validation

              if(something) {
                $value = $value;
              } elseif(something else) {
                $error = true;
                $value = $existing_value;
                
              }
             */

                $return['value'] = $value;
                $field['msg']    = 'your custom error message';
                if ( $error == true ) {
                    $return['error'] = $field;
                }

                return $return;
            }

            public static function class_field_callback( $field, $value ) {
                print_r( $field );
                echo '<br/>CLASS CALLBACK';
                print_r( $value );
            }

        }

        global $reduxConfig;
        $reduxConfig = new Redux_Framework_sample_config();
    } else {
        echo "The class named Redux_Framework_sample_config has already been called. <strong>Developers, you need to prefix this class with your company name or you'll run into problems!</strong>";
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ):
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    endif;

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ):
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error = true;
            $value = 'just testing';

            /*
          do your validation

          if(something) {
            $value = $value;
          } elseif(something else) {
            $error = true;
            $value = $existing_value;
            
          }
         */

            $return['value'] = $value;
            $field['msg']    = 'your custom error message';
            if ( $error == true ) {
                $return['error'] = $field;
            }

            $return['warning'] = $field;

            return $return;
        }
    endif;

/**

    Instagram

**/
function getInstagramAuthenticationField() {

    $field = array();

    $client_id = '';

    global $wpdb;
    $table_prefix = $wpdb->prefix;
    $table_name = $table_prefix . 'options';
    $option_name = 'mondo_admin_options';

    $mondo_options = $wpdb->get_results( $wpdb->prepare(
        "SELECT option_value FROM $table_name WHERE option_name = %s",
        $option_name
    ), ARRAY_A );
    
    if ( $mondo_options ) {
        $unserialized_options = unserialize( $mondo_options[0]['option_value'] );
        if ( isset( $unserialized_options['instagram_client_id'] ) ) {
            $client_id = $unserialized_options['instagram_client_id'];
        }
    }

    if ( ! get_theme_mod( 'instagram_access_token' ) ) {
        $field = array(
            'id'         => 'info_instagram_authentication',
            'type'       => 'raw',
            'title'      => __('Instagram Authentication', 'mondo'),
            'content'    => '<a href="https://api.instagram.com/oauth/authorize/?client_id=' . $client_id . '&amp;redirect_uri=' . urlencode ( admin_url() . 'admin.php?page=_options' ) . '&amp;response_type=code">Sign In with Instagram</a>',
            'full_width' => false,
        );
    } else {
        $field = array(
            'id'         => 'info_instagram_authentication',
            'type'       => 'raw',
            'title'      => __('Instagram Authentication', 'mondo'),
            'content'    => '<div class="clearfix"><div class="pull-left instagram-profile-picture"><img src="' . get_theme_mod( 'instagram_profile_picture' ) . '"></div>' . '<div class="pull-left instagram-user-info">' . '<div class="instagram-full-name">' . get_theme_mod( 'instagram_full_name' ) . '</div><div class="instagram-username">' . get_theme_mod( 'instagram_username' ) . '</div></div>' . '<a href="' . admin_url() . 'admin.php?page=_options&amp;instagram_reset=true" class="button instagram-reset-button">Reset</a></div>',
            'full_width' => false,
        );
    }

    return $field;
}

function instagram_authentication() {

    if ( isset( $_GET['code'] ) ) {

        global $mondo_admin_data;

        if ( $mondo_admin_data['instagram_client_id'] != '' && $mondo_admin_data['instagram_client_secret'] ) {
            $client_id = $mondo_admin_data['instagram_client_id'];
            $client_secret = $mondo_admin_data['instagram_client_secret'];
        }

        if ( isset( $client_id ) && isset( $client_secret ) ) {
            $response = wp_remote_post( 'https://api.instagram.com/oauth/access_token',
                array(
                    'body'      => array(
                        'code'          => $_GET['code'],
                        'response_type' => 'authorization_code',
                        'redirect_uri'  => admin_url() . 'admin.php?page=_options',
                        'client_id'     => $client_id,
                        'client_secret' => $client_secret,
                        'grant_type'    => 'authorization_code',
                    ),
                    'sslverify' => apply_filters( 'https_local_ssl_verify', false )
                )
            );
        }

        $access_token = null;
        $username = null;
        $profile_picture = null;
        $success = false;
        $errormessage = null;
        $errortype = null;

        if ( ! is_wp_error( $response ) ) {

            $auth = json_decode( $response['body'] );
            
            if ( isset( $auth->access_token ) ) {

                $access_token = $auth->access_token;
                $username = $auth->user->username;
                $user_id = get_instagram_user_id( $username, $access_token );
                $profile_picture = $auth->user->profile_picture;
                $full_name = $auth->user->full_name;

                set_theme_mod( 'instagram_access_token', $access_token );
                set_theme_mod( 'instagram_user_id', $user_id );
                set_theme_mod( 'instagram_username', $username );
                set_theme_mod( 'instagram_profile_picture', $profile_picture );
                set_theme_mod( 'instagram_full_name', $full_name );

                $success = true;
                wp_redirect( admin_url() . 'admin.php?page=_options' );
            }
        }

        if ( ! $access_token ) {
            echo 'no access token!';
        }
    }
}

if ( isset( $_GET['code'] ) ) {
    instagram_authentication();
}
if ( isset( $_GET['instagram_reset']) ) {
    if ( $_GET['instagram_reset'] ) {
        remove_theme_mod( 'instagram_access_token' );
        remove_theme_mod( 'instagram_user_id' );
        remove_theme_mod( 'instagram_username' );
        remove_theme_mod( 'instagram_profile_picture' );
        remove_theme_mod( 'instagram_full_name' );
        wp_redirect( admin_url() . 'admin.php?page=_options' );
    }
}
