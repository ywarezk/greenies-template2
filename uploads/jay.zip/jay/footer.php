<?php
	global $mondo_admin_data;

	$footer_class = 'site-footer page-footer';
	$footer_class .= ' ' . $mondo_admin_data['footer_style'];
?>
	
	</div><!-- .row -->
		</div><!-- #content -->

	<?php
		if ( $mondo_admin_data['enable_media_feed'] == '1' ) {
			mondo_media_feed();
		}
	?>

	<a href="#" id="go-top" disabled="disabled"><i class="mdi mdi-upload"></i></a>

	<footer id="colophon" class="<?php echo esc_attr( $footer_class ); ?>" role="contentinfo">

		<?php if ( $mondo_admin_data['footer_style'] == 'widgetized' ) : ?>
			<div class="top">
				<div class="container">
					<div class="row">
						<?php dynamic_sidebar( 'widget-footer' ); ?>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<div class="bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="copyright">
							<?php if ( isset( $mondo_admin_data['copyright_text'] ) && mondo_redux_text_set( $mondo_admin_data['copyright_text'] ) ) : ?>
								<?php echo wp_kses( $mondo_admin_data['copyright_text'], array(
									'a'      => array( 'href' => array() ),
									'span'   => array( 'style' => array() ),
									'i'      => array( 'class' => array(), 'style' => array() ),
									'em'     => array(),
									'strong' => array()
								) ); ?>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-md-6 text-right">
						<?php mondo_social_icons(); ?>
					</div>
				</div>
			</div>
		</div>

	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
